# ConnectLive — Mentor ID Verification (Frontend)

Premium, AI-guided mentor identity verification flow. Built as a **mock-first, backend-ready** frontend on TanStack Start: today it runs entirely on a client-side mock service; the moment you point `VITE_VERIFY_WS_URL` at a real WebSocket backend, the same UI drives production traffic with **zero component changes**.

- **Theme:** light-only, near-black text on white, electric-blue accents.
- **Type:** Sora (display), Manrope (body), JetBrains Mono (metrics/timers).
- **Stack:** TanStack Start v1 (React 19 + Vite 7), Tailwind v4, Zustand, Framer Motion.

---

## Verification flow

`/` → `/verify` (welcome + Gate 0) → `/verify/session` (guided flow) → `/verify/result/:id`.

1. **Gate 0 — pre-check** (silent, on `/verify` mount)
   - Enumerates cameras via `navigator.mediaDevices.enumerateDevices()`.
   - Blocks known virtual/suspicious camera drivers (OBS, ManyCam, Snap, XSplit, DroidCam, Iriun).
   - Placeholder for backend rate-limit response (429).
2. **Welcome** — explains the 3-part flow and privacy stance.
3. **ID card — front** — live rear camera, card outline overlay. Post-capture sub-statuses cycle: `Reading text` → `Checking image quality` → `Verifying watermark` → `Checking for edits`.
4. **Tilt / hologram check** — dedicated screen, animated tilt guide.
5. **ID card — back** — same pipeline as front.
6. **Bot-check** — arithmetic challenge, 3 questions, up to 3 attempts.
7. **Live face capture** — front camera, face oval, sub-statuses: `Comparing with ID photo` → `Checking liveness`.
8. **Liveness actions** — blink → turn left → turn right → hold steady, prompted one at a time.
9. **Consolidated processing** — single loader for server-only checks (template match, duplicate face/ID, expiry, scoring).
10. **Result** — verdict banner (Approved / Under review / Rejected) + 5 score rings (Liveness, Face Match, Document Authenticity, Data Match, Overall Trust) + per-side check rows + extracted OCR fields + captured frame thumbnails + JSON download.

---

## File map

| File | Purpose |
|------|---------|
| `src/routes/__root.tsx` | Root layout, head metadata, font links, error/not-found boundaries. |
| `src/routes/index.tsx` | Landing page — hero, live AI dashboard mock, agent pipeline, capabilities bento, how-it-works, CTAs. |
| `src/routes/verify.index.tsx` | `/verify` — welcome screen + Gate 0 pre-check (camera enumeration, rate limit). |
| `src/routes/verify.session.tsx` | `/verify/session` — the entire guided flow: renders CameraStage, sub-status card, action dock, retry banners. Subscribes to the verification service. |
| `src/routes/verify.result.$id.tsx` | `/verify/result/:id` — verdict banner, 5 score rings, per-side check rows with confidence %, OCR fields, capture thumbnails, JSON download. |
| `src/verification/types.ts` | **Full WebSocket contract.** Every client→server and server→client message shape, plus `VerificationResult`. |
| `src/verification/config.ts` | Central timing (`TIMING`), limits (`LIMITS`), phase labels, sub-status lists. Change durations here, not scattered. |
| `src/verification/store.ts` | Single Zustand store: phase, sub-status, connection status, captures, checks, scores, verdict. Every phase reads/writes here. |
| `src/verification/CameraStage.tsx` | Live `<video>` + transparent SVG overlay + hidden sampling canvas (~10fps sharpness estimate). Owns MediaStream lifecycle. |
| `src/services/verificationService.ts` | **The one file to touch when wiring a real backend.** Exports `VerificationService` interface + `MockVerificationService` + `WsVerificationService` + `createVerificationService()` factory. |

Every source file starts with a top-of-file comment explaining its purpose.

---

## WebSocket contract

All shapes live in `src/verification/types.ts`. The mock emits the same shapes the real backend must implement.

### Client → Server

```ts
type ClientMessage =
  | { type: "session_start"; sessionId: string }
  | { type: "begin" }
  | { type: "capture"; kind: CaptureKind; dataUrl: string }   // base64 frame
  | { type: "puzzle_answer"; index: number; answer: number }
  | { type: "frame_sharpness"; value: number }                // 0..100
  | { type: "abort" };
```

### Server → Client

```ts
type ServerMessage =
  | { type: "phase_start"; phase: Phase; durationMs: number }
  | { type: "phase_sub_status"; label: string; index: number; total: number }
  | { type: "hint"; message: string; level?: "info" | "warn" | "error" }
  | { type: "movement_prompt"; prompt: "blink" | "turn_left" | "turn_right" | "hold_steady" }
  | { type: "puzzle_question"; index: number; total: number; text: string }
  | { type: "puzzle_result"; correct: boolean; attemptsLeft: number }
  | { type: "capture_progress"; ms: number; totalMs: number; sharpness: number; seq: number }
  | { type: "captured"; kind: CaptureKind; dataUrl: string }
  | { type: "retry_required"; reason: string }
  | { type: "rate_limited"; retryAfterSec: number }
  | { type: "session_end"; result: VerificationResult };
```

`Phase` order: `front_scan → tilt → back_scan → puzzle → face_combo → liveness → processing → complete`.

`CaptureKind`: `front_scan | front_final | back_scan | back_final | face_combo | face_best`.

Stale `capture_progress` events (seq older than latest) are automatically dropped inside the service layer.

---

## Connecting a real backend

1. Copy `.env.example` to `.env` and set:
   ```
   VITE_VERIFY_WS_URL=wss://your-backend.example.com/verify
   ```
2. Implement a WebSocket server that:
   - Accepts a `session_start` message with the client-generated `sessionId`.
   - Runs the phases in `Phase` order, emitting `phase_start` + sub-statuses + hints.
   - Receives base64 captures and stores them.
   - Emits a final `session_end` with a `VerificationResult`.
3. **That's it.** No component changes. If the WS is unreachable within 3s, the frontend automatically falls back to the mock (dev only) with a console warning.

The **only file** you should ever need to touch to switch backends is `src/services/verificationService.ts`.

---

## Local development

```
bun install
bun run dev
```

- Runs on `http://localhost:8080`.
- Without `VITE_VERIFY_WS_URL`, the mock service drives the whole flow with realistic delays.
- Session results are stored in `sessionStorage` under `cl:result:<sessionId>` so `/verify/result/:id` can render immediately after redirect.

---

## Design tokens

Defined in `src/styles.css`:

- `--primary` `#2563eb`, `--primary-glow` `#60a5fa`, gradient utility `.bg-gradient-blue`.
- `--success` `#10b981` (approved), `--warning` `#f59e0b` (review), `--danger` `#ef4444` (rejected).
- No `.dark` overrides — the app is intentionally light-only.
