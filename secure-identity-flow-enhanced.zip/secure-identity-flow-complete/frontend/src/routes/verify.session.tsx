// /verify/session — the full guided verification flow.
// Reads a single Zustand store; drives a MockVerificationService by default
// or a real WebSocket backend when VITE_VERIFY_WS_URL is reachable.
import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  ShieldCheck,
  Camera,
  ArrowRight,
  RefreshCw,
  ChevronRight,
  RotateCw,
  Eye,
  Wifi,
  WifiOff,
} from "lucide-react";
import { CameraStage, captureVideoSnapshot, scoreVideoFrame, type FacingMode } from "../verification/CameraStage";
import { useVerificationStore } from "../verification/store";
import type { CaptureKind, ConnectionStatus, Phase, VerificationResult } from "../verification/types";
import { AUTO_CAPTURE_COPY, PHASE_LABELS, TIMING } from "../verification/config";
import { PHASE_ORDER } from "../verification/types";
import {
  createVerificationService,
  type VerificationService,
} from "../services/verificationService";

export const Route = createFileRoute("/verify/session")({
  head: () => ({
    meta: [
      { title: "Verification in progress — ConnectLive" },
      { name: "description", content: "AI-guided identity verification flow in progress." },
    ],
  }),
  component: VerifySession,
});

// [12/15] The manual capture kind for each phase that has one. id_combo has
// none — it's auto-only (see #5).
const MANUAL_KIND: Partial<Record<Phase, CaptureKind>> = {
  front_scan: "front_manual",
  back_scan: "back_manual",
  face_combo: "face_manual",
};
// [12/15] The auto-capture counterpart for the same phases.
const AUTO_KIND: Partial<Record<Phase, CaptureKind>> = {
  front_scan: "front_auto",
  back_scan: "back_auto",
  face_combo: "face_auto",
  id_combo: "face_id_combo",
};

type CaptureStage = "manual" | "auto-instruction" | "auto-sampling" | "done";

function VerifySession() {
  const navigate = useNavigate();
  const store = useVerificationStore();
  const [service, setService] = useState<VerificationService | null>(null);
  const videoElRef = useRef<HTMLVideoElement | null>(null);
  const [facing, setFacing] = useState<FacingMode>("environment");
  const [answer, setAnswer] = useState("");
  const captureLockRef = useRef(false);

  // [2/15,3/15,4/15,5/15] Where we are within the current phase's
  // manual -> auto-instruction -> auto-sampling -> done sequence.
  const [captureStage, setCaptureStage] = useState<CaptureStage>("manual");
  const [samplingProgress, setSamplingProgress] = useState(0);
  const tiltFramesSentRef = useRef(false);

  // Init service once
  useEffect(() => {
    let disposed = false;
    const id = crypto.randomUUID();
    store.reset(id);
    (async () => {
      const svc = await createVerificationService(id);
      if (disposed) { svc.disconnect(); return; }
      setService(svc);
      const off = svc.on((ev) => {
        if (ev.type === "connection") {
          store.setConnectionStatus(ev.status);
          if (ev.status === "error") store.setError("Connection lost");
        } else if (ev.type === "phase_start") {
          store.setPhase(ev.phase);
          store.setSubStatus(null);
          store.setHint(null);
          setAnswer("");
          captureLockRef.current = false;
          tiltFramesSentRef.current = false;
          // [12/15] id_combo has no manual step — jump straight to the
          // instruction screen. Every other camera phase starts manual.
          setCaptureStage(ev.phase === "id_combo" ? "auto-instruction" : "manual");
          setSamplingProgress(0);
          // Adjust facing per phase
          if (ev.phase === "face_combo" || ev.phase === "id_combo" || ev.phase === "liveness") setFacing("user");
          else setFacing("environment");
        } else if (ev.type === "phase_sub_status") {
          store.setSubStatus({ label: ev.label, index: ev.index, total: ev.total });
        } else if (ev.type === "hint") {
          store.setHint({ message: ev.message, level: ev.level ?? "info" });
        } else if (ev.type === "puzzle_question") {
          store.setPuzzleQuestion({ index: ev.index, total: ev.total, text: ev.text });
        } else if (ev.type === "puzzle_result") {
          store.setPuzzleAttemptsLeft(ev.attemptsLeft);
          if (ev.correct) setAnswer("");
        } else if (ev.type === "movement_prompt") {
          store.setMovementPrompt(ev.prompt);
        } else if (ev.type === "capture_progress") {
          store.setCaptureProgress({ ms: ev.ms, totalMs: ev.totalMs, sharpness: ev.sharpness });
        } else if (ev.type === "captured") {
          store.addCapture(ev.kind, ev.dataUrl);
        } else if (ev.type === "session_end") {
          finalizeAndNavigate(ev.result);
        }
      });
      svc.begin();
      return () => { off(); };
    })();
    return () => {
      disposed = true;
      service?.disconnect();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function finalizeAndNavigate(result: VerificationResult) {
    const withCaps = { ...result, captures: { ...result.captures, ...store.captures } };
    sessionStorage.setItem(`cl:result:${result.id}`, JSON.stringify(withCaps));
    store.applyResult(withCaps);
    navigate({ to: "/verify/result/$id", params: { id: result.id } });
  }

  // [1/15] Full-resolution manual capture — reads straight from the <video>
  // element instead of the old 320x180 sharpness-sampling canvas.
  function captureManual(kind: CaptureKind) {
    if (captureLockRef.current) return;
    const video = videoElRef.current;
    if (!video) return;
    const dataUrl = captureVideoSnapshot(video, facing === "user");
    if (!dataUrl) return;
    captureLockRef.current = true;
    store.addCapture(kind, dataUrl);
    service?.sendCapture(kind, dataUrl);
    setCaptureStage("auto-instruction");
  }

  // [2/15,3/15,4/15,5/15,14/15] Runs the 10-second best-frame auto-capture
  // sampling window for whichever phase is active, then submits the winner.
  useEffect(() => {
    if (captureStage !== "auto-sampling") return;
    const phase = store.phase as Phase;
    const autoKind = AUTO_KIND[phase];
    if (!autoKind) return;
    const video = videoElRef.current;
    if (!video) return;

    let cancelled = false;
    let best = { score: -1, dataUrl: "" };
    const start = Date.now();

    const tick = () => {
      if (cancelled) return;
      const elapsed = Date.now() - start;
      setSamplingProgress(Math.min(1, elapsed / TIMING.AUTO_CAPTURE_SAMPLE_MS));
      const score = scoreVideoFrame(video);
      if (score > best.score) {
        const shot = captureVideoSnapshot(video, facing === "user");
        if (shot) best = { score, dataUrl: shot };
      }
      if (elapsed >= TIMING.AUTO_CAPTURE_SAMPLE_MS) {
        finish();
        return;
      }
      timer = window.setTimeout(tick, TIMING.AUTO_CAPTURE_SAMPLE_INTERVAL_MS);
    };

    function finish() {
      if (cancelled) return;
      const finalUrl = best.dataUrl || captureVideoSnapshot(video!, facing === "user");
      if (finalUrl && autoKind) {
        store.addCapture(autoKind, finalUrl);
        service?.sendCapture(autoKind, finalUrl, Math.max(0, best.score));
      }
      setCaptureStage("done");
    }

    let timer = window.setTimeout(tick, TIMING.AUTO_CAPTURE_SAMPLE_INTERVAL_MS);
    return () => { cancelled = true; window.clearTimeout(timer); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [captureStage, store.phase, facing]);

  // [13/15] Advance from the instruction screen into sampling after a short
  // beat so the user actually reads it — not a silent jump.
  useEffect(() => {
    if (captureStage !== "auto-instruction") return;
    const t = window.setTimeout(() => setCaptureStage("auto-sampling"), TIMING.AUTO_CAPTURE_INSTRUCTION_MS);
    return () => window.clearTimeout(t);
  }, [captureStage]);

  // [8/15,9/15] Tilt phase: capture two real angled frames a few seconds
  // apart (instead of silently reusing the front photo) so the backend can
  // run a genuine dual-frame hologram comparison.
  useEffect(() => {
    if (store.phase !== "tilt" || tiltFramesSentRef.current) return;
    tiltFramesSentRef.current = true;
    const t1 = window.setTimeout(() => {
      const video = videoElRef.current;
      if (!video) return;
      const shot = captureVideoSnapshot(video, false);
      if (shot) { store.addCapture("tilt_frame_1", shot); service?.sendCapture("tilt_frame_1", shot); }
    }, 2200);
    const t2 = window.setTimeout(() => {
      const video = videoElRef.current;
      if (!video) return;
      const shot = captureVideoSnapshot(video, false);
      if (shot) { store.addCapture("tilt_frame_2", shot); service?.sendCapture("tilt_frame_2", shot); }
    }, 5200);
    return () => { window.clearTimeout(t1); window.clearTimeout(t2); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [store.phase]);

  function submitAnswer() {
    if (!store.puzzleQuestion) return;
    const n = Number(answer);
    if (Number.isNaN(n)) return;
    service?.submitPuzzleAnswer(store.puzzleQuestion.index, n);
  }

  function reconnect() {
    window.location.reload();
  }

  function recapture() {
    const phase = store.phase as Phase;
    captureLockRef.current = false;
    setCaptureStage(phase === "id_combo" ? "auto-instruction" : "manual");
  }

  const phase = store.phase;
  const stepIndex = Math.max(0, PHASE_ORDER.indexOf(phase as Phase));

  return (
    <div className="min-h-screen bg-background">
      <SessionTopBar
        stepIndex={stepIndex}
        connectionStatus={store.connectionStatus}
      />

      <div className="mx-auto max-w-5xl px-4 pt-4">
        <StatusPill status={store.connectionStatus} />
      </div>

      <main className="mx-auto grid max-w-5xl gap-6 px-4 pb-24 pt-4 lg:grid-cols-[1fr_320px]">
        <div className="space-y-4">
          {phase === "welcome" && (
            <div className="rounded-2xl border border-border bg-card p-8 text-center">
              <Camera className="mx-auto h-8 w-8 text-primary" />
              <p className="mt-3 text-sm text-muted-foreground">Getting things ready…</p>
            </div>
          )}

          {(phase === "front_scan" || phase === "back_scan") && (
            <div className="relative">
              <CameraStage
                facingMode={facing}
                onVideoReady={(v) => (videoElRef.current = v)}
                onSharpness={(v) => service?.updateFrameSharpness(v)}
                overlay={<CardOverlay />}
              />
              {captureStage !== "manual" && (
                <AutoCaptureOverlay
                  kind={MANUAL_KIND[phase as Phase]!}
                  stage={captureStage}
                  progress={samplingProgress}
                />
              )}
            </div>
          )}
          {phase === "tilt" && (
            <CameraStage
              facingMode={facing}
              onVideoReady={(v) => (videoElRef.current = v)}
              overlay={<TiltOverlay />}
            />
          )}
          {phase === "face_combo" && (
            <div className="relative">
              <CameraStage
                facingMode={facing}
                onVideoReady={(v) => (videoElRef.current = v)}
                onSharpness={(v) => service?.updateFrameSharpness(v)}
                overlay={<FaceOverlay />}
              />
              {captureStage !== "manual" && (
                <AutoCaptureOverlay kind="face_manual" stage={captureStage} progress={samplingProgress} />
              )}
            </div>
          )}
          {/* [5/15] Brand-new, auto-only Face + ID combo screen — same visual
              language as the other camera stages, new overlay + copy. */}
          {phase === "id_combo" && (
            <div className="relative">
              <CameraStage
                facingMode={facing}
                onVideoReady={(v) => (videoElRef.current = v)}
                overlay={<IdComboOverlay />}
              />
              <AutoCaptureOverlay kind="face_id_combo" stage={captureStage} progress={samplingProgress} />
            </div>
          )}
          {phase === "liveness" && (
            <CameraStage
              facingMode={facing}
              onVideoReady={(v) => (videoElRef.current = v)}
              onSharpness={(v) => service?.updateFrameSharpness(v)}
              overlay={<FaceOverlay />}
            />
          )}
          {(phase === "puzzle" || phase === "processing") && (
            <div className="rounded-2xl border border-border bg-card p-10 min-h-[420px] grid place-items-center">
              {phase === "puzzle" ? (
                <PuzzleUi
                  q={store.puzzleQuestion}
                  attemptsLeft={store.puzzleAttemptsLeft}
                  answer={answer}
                  setAnswer={setAnswer}
                  onSubmit={submitAnswer}
                />
              ) : (
                <ProcessingUi label={store.subStatus?.label ?? "Finalizing"} />
              )}
            </div>
          )}

          {/* Retry banner */}
          <AnimatePresence>
            {store.hint && store.hint.level !== "info" && (
              <motion.div
                initial={{ opacity: 0, y: -6 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className={`flex items-center justify-between rounded-xl border px-4 py-3 text-sm ${
                  store.hint.level === "error"
                    ? "border-danger/40 bg-danger/5 text-danger"
                    : "border-warning/40 bg-warning/5 text-warning"
                }`}
              >
                <span>{store.hint.message}</span>
                <button
                  onClick={recapture}
                  className="inline-flex items-center gap-1.5 rounded-full border border-current px-3 py-1 text-xs"
                >
                  <RotateCw className="h-3 w-3" /> Recapture
                </button>
              </motion.div>
            )}
            {store.connectionStatus === "error" && (
              <motion.div
                initial={{ opacity: 0, y: -6 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className="flex items-center justify-between rounded-xl border border-danger/40 bg-danger/5 px-4 py-3 text-sm text-danger"
              >
                <span className="flex items-center gap-2">
                  <WifiOff className="h-4 w-4" /> Connection lost — reconnect to continue.
                </span>
                <button
                  onClick={reconnect}
                  className="inline-flex items-center gap-1.5 rounded-full border border-current px-3 py-1 text-xs"
                >
                  <RefreshCw className="h-3 w-3" /> Reconnect
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <aside className="space-y-4">
          <PhaseInfo phase={phase} sub={store.subStatus} />
          <ActionDock
            phase={phase}
            captureStage={captureStage}
            onCapture={captureManual}
            movementPrompt={store.movementPrompt}
          />
        </aside>
      </main>
    </div>
  );
}

function SessionTopBar({
  stepIndex,
  connectionStatus,
}: {
  stepIndex: number;
  connectionStatus: ConnectionStatus;
}) {
  const total = PHASE_ORDER.length;
  return (
    <header className="border-b border-border/60 bg-background/90 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-5xl items-center justify-between px-4">
        <Link to="/" className="flex items-center gap-2">
          <div className="grid h-8 w-8 place-items-center rounded-lg bg-gradient-blue text-white">
            <ShieldCheck className="h-4 w-4" />
          </div>
          <span className="font-display text-lg font-semibold tracking-tight">ConnectLive</span>
        </Link>
        <div className="hidden items-center gap-2 font-mono text-xs uppercase tracking-wider text-muted-foreground sm:flex">
          Step {Math.min(stepIndex + 1, total)} of {total}
        </div>
        <div className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
          {connectionStatus === "live" || connectionStatus === "processing" ? (
            <Wifi className="h-3.5 w-3.5 text-success" />
          ) : (
            <WifiOff className="h-3.5 w-3.5" />
          )}
          {connectionStatus}
        </div>
      </div>
      <div className="mx-auto max-w-5xl px-4 pb-3">
        <div className="h-1.5 w-full overflow-hidden rounded-full bg-muted">
          <motion.div
            className="h-full bg-gradient-blue"
            animate={{ width: `${((stepIndex + 1) / total) * 100}%` }}
            transition={{ duration: 0.4 }}
          />
        </div>
      </div>
    </header>
  );
}

function StatusPill({ status }: { status: ConnectionStatus }) {
  const map: Record<ConnectionStatus, { dot: string; label: string }> = {
    idle: { dot: "bg-muted-foreground", label: "idle" },
    connecting: { dot: "bg-warning animate-pulse", label: "connecting" },
    live: { dot: "bg-success animate-pulse", label: "live" },
    processing: { dot: "bg-primary animate-pulse", label: "processing" },
    done: { dot: "bg-success", label: "done" },
    error: { dot: "bg-danger", label: "error" },
  };
  const s = map[status];
  return (
    <div className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-3 py-1 font-mono text-[11px] uppercase tracking-wider text-muted-foreground">
      <span className={`h-1.5 w-1.5 rounded-full ${s.dot}`} />
      {s.label}
    </div>
  );
}

function PhaseInfo({ phase, sub }: { phase: Phase; sub: { label: string; index: number; total: number } | null }) {
  const label = PHASE_LABELS[phase] ?? "Getting ready";
  return (
    <div className="rounded-2xl border border-border bg-card p-5">
      <div className="font-mono text-[10px] uppercase tracking-wider text-primary">Current step</div>
      <h2 className="mt-1 font-display text-xl font-semibold">{label}</h2>
      {sub && (
        <div className="mt-4 rounded-lg border border-border bg-muted/50 p-3">
          <div className="flex items-center justify-between font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
            <span>Sub-status</span>
            <span>{sub.index}/{sub.total}</span>
          </div>
          <div className="mt-1 text-sm font-medium">{sub.label}…</div>
        </div>
      )}
      <p className="mt-4 text-xs text-muted-foreground">
        Timers are generous. Take your time — the flow won't reject you for being slow.
      </p>
    </div>
  );
}

function ActionDock({
  phase,
  captureStage,
  onCapture,
  movementPrompt,
}: {
  phase: Phase;
  captureStage: CaptureStage;
  onCapture: (k: CaptureKind) => void;
  movementPrompt: string | null;
}) {
  const manualDone = captureStage !== "manual";
  return (
    <div className="rounded-2xl border border-border bg-card p-5">
      {phase === "front_scan" && (
        manualDone ? (
          <AutoStatusNote stage={captureStage} />
        ) : (
          <ActionBtn label="Capture front" onClick={() => onCapture("front_manual")} />
        )
      )}
      {phase === "back_scan" && (
        manualDone ? (
          <AutoStatusNote stage={captureStage} />
        ) : (
          <ActionBtn label="Capture back" onClick={() => onCapture("back_manual")} />
        )
      )}
      {phase === "tilt" && (
        <div className="text-center text-sm text-muted-foreground">
          <Eye className="mx-auto mb-2 h-5 w-5 text-primary" />
          Slowly tilt your card left and right — we'll grab two angles automatically.
        </div>
      )}
      {phase === "face_combo" && (
        manualDone ? (
          <AutoStatusNote stage={captureStage} />
        ) : (
          <ActionBtn label="Capture face" onClick={() => onCapture("face_manual")} />
        )
      )}
      {phase === "id_combo" && <AutoStatusNote stage={captureStage} isCombo />}
      {phase === "liveness" && (
        <div className="text-center">
          <div className="font-mono text-[10px] uppercase tracking-wider text-primary">Prompt</div>
          <div className="mt-1 font-display text-lg">
            {promptLabel(movementPrompt)}
          </div>
        </div>
      )}
      {phase === "puzzle" && (
        <div className="text-center text-sm text-muted-foreground">
          Answer the challenge to prove you're human.
        </div>
      )}
      {phase === "processing" && (
        <div className="text-center text-sm text-muted-foreground">
          Our agents are finalizing your result.
        </div>
      )}
      {phase === "welcome" && (
        <div className="text-center text-sm text-muted-foreground">Starting session…</div>
      )}
    </div>
  );
}

function AutoStatusNote({ stage, isCombo }: { stage: CaptureStage; isCombo?: boolean }) {
  if (stage === "auto-instruction") {
    return (
      <div className="text-center text-sm text-muted-foreground">
        <Camera className="mx-auto mb-2 h-5 w-5 text-primary" />
        {isCombo ? "Hold your ID next to your face…" : "Nice — now hold steady for a backup shot."}
      </div>
    );
  }
  if (stage === "auto-sampling") {
    return (
      <div className="text-center text-sm text-muted-foreground">
        <RefreshCw className="mx-auto mb-2 h-5 w-5 animate-spin text-primary" />
        Auto-capturing the best frame…
      </div>
    );
  }
  return (
    <div className="text-center text-sm text-muted-foreground">
      <ShieldCheck className="mx-auto mb-2 h-5 w-5 text-success" />
      Captured. Moving on…
    </div>
  );
}

function ActionBtn({ label, onClick }: { label: string; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="inline-flex w-full items-center justify-center gap-2 rounded-full bg-gradient-blue px-5 py-3 text-sm font-medium text-white shadow-lg blue-glow transition hover:opacity-95"
    >
      {label} <ChevronRight className="h-4 w-4" />
    </button>
  );
}

function promptLabel(p: string | null) {
  switch (p) {
    case "blink": return "Blink naturally";
    case "turn_left": return "Turn head slowly left";
    case "turn_right": return "Turn head slowly right";
    case "hold_steady": return "Hold steady";
    default: return "Get ready";
  }
}

// [13/15] Two-step overlay shown over the live camera: a brief instruction
// card, then a scanning-style progress ring during the sampling window —
// never a silent timer.
function AutoCaptureOverlay({
  kind,
  stage,
  progress,
}: {
  kind: CaptureKind;
  stage: CaptureStage;
  progress: number;
}) {
  if (stage === "manual" || stage === "done") return null;
  const copy = AUTO_CAPTURE_COPY[kind] ?? { instruction: "Hold steady — auto-capturing…", sampling: "Sampling the best frame…" };
  return (
    <div className="absolute inset-0 flex items-center justify-center rounded-2xl bg-black/55 backdrop-blur-sm px-6 text-center">
      {stage === "auto-instruction" ? (
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="max-w-xs">
          <Camera className="mx-auto mb-3 h-7 w-7 text-white" />
          <p className="text-sm font-medium text-white">{copy.instruction}</p>
        </motion.div>
      ) : (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="max-w-xs">
          <div className="relative mx-auto mb-3 h-14 w-14">
            <svg viewBox="0 0 56 56" className="h-14 w-14 -rotate-90">
              <circle cx="28" cy="28" r="24" fill="none" stroke="rgba(255,255,255,0.25)" strokeWidth="4" />
              <circle
                cx="28" cy="28" r="24" fill="none" stroke="#60a5fa" strokeWidth="4"
                strokeDasharray={2 * Math.PI * 24}
                strokeDashoffset={2 * Math.PI * 24 * (1 - progress)}
                strokeLinecap="round"
              />
            </svg>
          </div>
          <p className="text-sm font-medium text-white">{copy.sampling}</p>
        </motion.div>
      )}
    </div>
  );
}

function CardOverlay() {
  return (
    <svg className="absolute inset-0 h-full w-full" viewBox="0 0 400 300" preserveAspectRatio="none">
      <rect x="30" y="55" width="340" height="190" rx="14" fill="none" stroke="#60a5fa" strokeWidth="2" strokeDasharray="6 6" opacity="0.85" />
      {[[30,55],[370,55],[30,245],[370,245]].map(([x,y],i) => (
        <g key={i} stroke="#2563eb" strokeWidth="3" fill="none">
          <path d={`M${x + (x<200?0:-16)} ${y + (y<150?12:-12)} L${x} ${y} L${x + (x<200?12:-12)} ${y}`} />
        </g>
      ))}
    </svg>
  );
}
function TiltOverlay() {
  return (
    <svg className="absolute inset-0 h-full w-full" viewBox="0 0 400 300" preserveAspectRatio="none">
      <rect x="60" y="70" width="280" height="170" rx="14" fill="none" stroke="#60a5fa" strokeWidth="2" strokeDasharray="6 6" opacity="0.7" />
      <g stroke="#2563eb" strokeWidth="3" fill="none">
        <path d="M40 155 L70 145 L70 165 Z" fill="#2563eb" />
        <path d="M360 155 L330 145 L330 165 Z" fill="#2563eb" />
      </g>
    </svg>
  );
}
function FaceOverlay() {
  return (
    <svg className="absolute inset-0 h-full w-full" viewBox="0 0 400 300" preserveAspectRatio="none">
      <ellipse cx="200" cy="150" rx="90" ry="115" fill="none" stroke="#60a5fa" strokeWidth="2" strokeDasharray="6 6" />
      <ellipse cx="200" cy="150" rx="90" ry="115" fill="none" stroke="#2563eb" strokeWidth="2" className="animate-pulse-ring" />
    </svg>
  );
}
// [5/15] New overlay: face oval + card rectangle side-by-side, guiding the
// user to hold the ID next to their face for the combo anti-spoof shot.
function IdComboOverlay() {
  return (
    <svg className="absolute inset-0 h-full w-full" viewBox="0 0 400 300" preserveAspectRatio="none">
      <ellipse cx="150" cy="140" rx="65" ry="85" fill="none" stroke="#60a5fa" strokeWidth="2" strokeDasharray="6 6" />
      <rect x="230" y="105" width="130" height="82" rx="10" fill="none" stroke="#2563eb" strokeWidth="2" strokeDasharray="6 6" />
    </svg>
  );
}

function PuzzleUi({
  q,
  attemptsLeft,
  answer,
  setAnswer,
  onSubmit,
}: {
  q: { index: number; total: number; text: string } | null;
  attemptsLeft: number;
  answer: string;
  setAnswer: (s: string) => void;
  onSubmit: () => void;
}) {
  if (!q) return <div className="text-muted-foreground">Preparing challenge…</div>;
  return (
    <div className="w-full max-w-sm text-center">
      <div className="font-mono text-[10px] uppercase tracking-wider text-primary">
        Question {q.index + 1} of {q.total}
      </div>
      <div className="mt-4 font-display text-4xl font-semibold">
        <SyntheticEquation seed={q.index} />
      </div>
      <input
        autoFocus
        type="number"
        value={answer}
        onChange={(e) => setAnswer(e.target.value)}
        onKeyDown={(e) => e.key === "Enter" && onSubmit()}
        className="mt-6 w-full rounded-xl border border-border bg-background px-4 py-3 text-center font-mono text-xl focus:outline-none focus:ring-2 focus:ring-primary"
        placeholder="?"
      />
      <div className="mt-3 font-mono text-xs text-muted-foreground">
        {attemptsLeft} attempts left
      </div>
      <button
        onClick={onSubmit}
        className="mt-6 inline-flex items-center gap-2 rounded-full bg-gradient-blue px-6 py-2.5 text-sm font-medium text-white shadow-md"
      >
        Submit <ArrowRight className="h-4 w-4" />
      </button>
    </div>
  );
}

// Deterministic equation matched to a seed so display stays consistent.
function SyntheticEquation({ seed }: { seed: number }) {
  const eq = useMemo(() => {
    const rng = mulberry32(1234 + seed);
    const a = 3 + Math.floor(rng() * 12);
    const b = 2 + Math.floor(rng() * 9);
    const ops = ["+", "-", "×"] as const;
    const op = ops[Math.floor(rng() * 3)];
    return `${a} ${op} ${b}`;
  }, [seed]);
  return <span className="font-mono">{eq} = ?</span>;
}
function mulberry32(a: number) {
  return function () {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function ProcessingUi({ label }: { label: string }) {
  return (
    <div className="text-center">
      <div className="mx-auto grid h-16 w-16 place-items-center rounded-2xl bg-primary/10 text-primary">
        <RefreshCw className="h-7 w-7 animate-spin" />
      </div>
      <div className="mt-5 font-display text-xl font-semibold">Finalizing your result</div>
      <div className="mt-2 font-mono text-sm text-muted-foreground">{label}…</div>
      <div className="mx-auto mt-6 h-1 w-56 overflow-hidden rounded-full bg-muted">
        <motion.div
          className="h-full bg-gradient-blue"
          animate={{ x: ["-100%", "100%"] }}
          transition={{ duration: 1.4, repeat: Infinity, ease: "easeInOut" }}
        />
      </div>
    </div>
  );
}

// Session cap enforcement (best-effort)
export function _sessionCap() { return TIMING.SESSION_TOTAL_CAP_MS; }
