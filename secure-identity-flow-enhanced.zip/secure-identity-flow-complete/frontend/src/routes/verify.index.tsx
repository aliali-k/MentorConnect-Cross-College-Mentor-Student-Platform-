// /verify — Welcome + Gate 0 pre-check (camera enumeration + rate-limit gate).
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { ArrowRight, ShieldCheck, Camera, AlertTriangle, Clock } from "lucide-react";

export const Route = createFileRoute("/verify/")({
  head: () => ({
    meta: [
      { title: "Verify your identity — ConnectLive" },
      {
        name: "description",
        content:
          "Start your mentor identity verification. AI-guided, camera-only, done in under five minutes.",
      },
    ],
  }),
  component: VerifyWelcome,
});

const SUSPICIOUS = ["obs", "manycam", "snap camera", "xsplit", "virtual", "droidcam", "iriun"];

function VerifyWelcome() {
  const navigate = useNavigate();
  const [state, setState] = useState<"checking" | "ready" | "blocked" | "rate_limited">("checking");
  const [blockedReason, setBlockedReason] = useState("");

  useEffect(() => {
    let cancelled = false;
    async function check() {
      // Mock rate-limit check (real backend would return 429)
      const rateLimited = false;
      if (rateLimited) {
        if (!cancelled) setState("rate_limited");
        return;
      }
      try {
        const devices = await navigator.mediaDevices.enumerateDevices();
        const cams = devices.filter((d) => d.kind === "videoinput");
        if (cams.length === 0) {
          if (!cancelled) {
            setState("blocked");
            setBlockedReason("No camera detected on this device.");
          }
          return;
        }
        const suspicious = cams.find((c) =>
          SUSPICIOUS.some((s) => c.label.toLowerCase().includes(s)),
        );
        if (suspicious) {
          if (!cancelled) {
            setState("blocked");
            setBlockedReason(
              "A virtual camera driver was detected. Please use your device's built-in camera.",
            );
          }
          return;
        }
        if (!cancelled) setState("ready");
      } catch {
        if (!cancelled) setState("ready"); // permission not yet granted, but we can proceed
      }
    }
    check();
    return () => { cancelled = true; };
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <TopBar />
      <div className="mx-auto flex max-w-3xl flex-col items-center px-6 py-16">
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full rounded-3xl border border-border bg-card p-8 shadow-xl"
        >
          {state === "checking" && <StatusCard icon={Camera} title="Preparing…" body="Checking your camera setup." />}
          {state === "blocked" && (
            <StatusCard
              icon={AlertTriangle}
              title="Camera not supported"
              body={blockedReason}
              tone="danger"
            />
          )}
          {state === "rate_limited" && (
            <StatusCard
              icon={Clock}
              title="Too many attempts"
              body="Please try again in 15 minutes."
              tone="warn"
            />
          )}
          {state === "ready" && (
            <div>
              <span className="inline-flex items-center gap-2 rounded-full border border-primary/20 bg-primary/5 px-3 py-1 text-xs font-mono uppercase tracking-wider text-primary">
                <ShieldCheck className="h-3.5 w-3.5" /> Verification
              </span>
              <h1 className="mt-5 font-display text-3xl font-semibold tracking-tight">
                Let's verify your identity.
              </h1>
              <p className="mt-3 text-muted-foreground">
                You'll go through three quick parts: your ID card, a fast bot check, and a
                short face + liveness capture. Total time is about four to five minutes.
              </p>

              <ul className="mt-6 space-y-3">
                {[
                  ["ID card scan", "Front, tilt for hologram, then back."],
                  ["Bot check", "A short arithmetic challenge."],
                  ["Face & liveness", "Blink and turn your head slowly."],
                ].map(([t, d]) => (
                  <li key={t} className="flex items-start gap-3 rounded-xl border border-border bg-background p-4">
                    <div className="mt-0.5 grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-primary/10 text-primary font-mono text-sm">
                      ✓
                    </div>
                    <div>
                      <div className="font-medium">{t}</div>
                      <div className="text-sm text-muted-foreground">{d}</div>
                    </div>
                  </li>
                ))}
              </ul>

              <div className="mt-6 rounded-xl border border-border bg-muted/40 p-4 text-xs text-muted-foreground">
                Your data is processed securely and never shared with third parties. Frames are
                purged after a decision.
              </div>

              <div className="mt-8 flex items-center justify-between gap-3">
                <Link to="/" className="text-sm text-muted-foreground hover:text-foreground">
                  ← Back
                </Link>
                <button
                  onClick={() => navigate({ to: "/verify/session" })}
                  className="inline-flex items-center gap-2 rounded-full bg-gradient-blue px-6 py-3 text-sm font-medium text-white shadow-lg blue-glow transition hover:opacity-95"
                >
                  Start verification <ArrowRight className="h-4 w-4" />
                </button>
              </div>
            </div>
          )}
        </motion.div>
      </div>
    </div>
  );
}

function TopBar() {
  return (
    <header className="border-b border-border/60 bg-background/80 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-6">
        <Link to="/" className="flex items-center gap-2">
          <div className="grid h-8 w-8 place-items-center rounded-lg bg-gradient-blue text-white">
            <ShieldCheck className="h-4 w-4" />
          </div>
          <span className="font-display text-lg font-semibold tracking-tight">ConnectLive</span>
        </Link>
        <span className="font-mono text-xs uppercase tracking-wider text-muted-foreground">
          Mentor verification
        </span>
      </div>
    </header>
  );
}

function StatusCard({
  icon: Icon,
  title,
  body,
  tone = "info",
}: {
  icon: typeof Camera;
  title: string;
  body: string;
  tone?: "info" | "warn" | "danger";
}) {
  const toneClass =
    tone === "danger"
      ? "text-danger bg-danger/10"
      : tone === "warn"
        ? "text-warning bg-warning/10"
        : "text-primary bg-primary/10";
  return (
    <div className="text-center">
      <div className={`mx-auto grid h-12 w-12 place-items-center rounded-2xl ${toneClass}`}>
        <Icon className="h-6 w-6" />
      </div>
      <h1 className="mt-4 font-display text-2xl font-semibold">{title}</h1>
      <p className="mt-2 text-muted-foreground">{body}</p>
    </div>
  );
}
