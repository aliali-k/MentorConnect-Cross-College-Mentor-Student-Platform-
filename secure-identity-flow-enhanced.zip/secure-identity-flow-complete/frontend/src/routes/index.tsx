// Landing page: split-screen hero, live AI dashboard mock, AI agent pipeline,
// capabilities bento, how-it-works, privacy strip, final CTA, footer.
import { createFileRoute, Link } from "@tanstack/react-router";
import { motion, useReducedMotion } from "framer-motion";
import { useEffect, useState } from "react";
import {
  ArrowRight,
  ShieldCheck,
  ScanLine,
  Eye,
  Fingerprint,
  Users,
  Gauge,
  Lock,
  MonitorSmartphone,
  Cpu,
} from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "ConnectLive — AI-guided mentor identity verification" },
      {
        name: "description",
        content:
          "Verify mentor identity in under 5 minutes. Real-time AI agents for OCR, liveness, face match, and anti-spoof — auditable and encrypted.",
      },
      { property: "og:title", content: "ConnectLive — AI-guided mentor identity verification" },
      {
        property: "og:description",
        content:
          "Real-time AI monitoring for ID, liveness, and face-match. Trust scored in under 5 minutes.",
      },
    ],
  }),
  component: Landing,
});

function Landing() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <Nav />
      <Hero />
      <TrustStrip />
      <AgentPipeline />
      <CapabilitiesBento />
      <HowItWorks />
      <PrivacyStrip />
      <FinalCta />
      <Footer />
    </div>
  );
}

function Nav() {
  return (
    <header className="sticky top-0 z-50 border-b border-border/60 bg-background/80 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-6">
        <Link to="/" className="flex items-center gap-2">
          <div className="grid h-8 w-8 place-items-center rounded-lg bg-gradient-blue text-white">
            <ShieldCheck className="h-4 w-4" />
          </div>
          <span className="font-display text-lg font-semibold tracking-tight">ConnectLive</span>
        </Link>
        <nav className="hidden items-center gap-8 md:flex text-sm text-muted-foreground">
          <a href="#how" className="hover:text-foreground">How it works</a>
          <a href="#agents" className="hover:text-foreground">AI agents</a>
          <a href="#privacy" className="hover:text-foreground">Privacy</a>
        </nav>
        <div className="flex items-center gap-2">
          <a href="#" className="hidden text-sm text-muted-foreground hover:text-foreground md:inline">
            Sign in
          </a>
          <Link
            to="/verify"
            className="inline-flex items-center gap-1.5 rounded-full bg-gradient-blue px-4 py-2 text-sm font-medium text-white shadow-sm transition hover:opacity-95"
          >
            Start verification <ArrowRight className="h-3.5 w-3.5" />
          </Link>
        </div>
      </div>
    </header>
  );
}

function Hero() {
  return (
    <section className="relative overflow-hidden">
      <div className="pointer-events-none absolute inset-0 grid-bg opacity-40" />
      <div className="pointer-events-none absolute -top-40 right-0 h-[420px] w-[420px] rounded-full bg-primary-glow/20 blur-3xl" />
      <div className="mx-auto grid max-w-7xl gap-14 px-6 py-20 lg:grid-cols-2 lg:py-28">
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="flex flex-col justify-center"
        >
          <span className="mb-5 inline-flex w-fit items-center gap-2 rounded-full border border-primary/20 bg-primary/5 px-3 py-1 text-xs font-medium tracking-wider text-primary uppercase font-mono">
            <span className="h-1.5 w-1.5 rounded-full bg-primary animate-pulse-ring" />
            AI-guided identity verification
          </span>
          <h1 className="font-display text-5xl font-semibold leading-[1.05] tracking-tight sm:text-6xl">
            Onboard mentors in minutes.
            <br />
            <span className="text-gradient-blue">Verified by AI agents.</span>
          </h1>
          <p className="mt-6 max-w-lg text-lg leading-relaxed text-muted-foreground">
            ConnectLive runs a live pipeline of AI agents — OCR, liveness, 3-way face match,
            anti-spoof — while the mentor scans their ID and shows their face. You get a
            transparent trust score, they get done in under five minutes.
          </p>
          <div className="mt-8 flex flex-wrap items-center gap-3">
            <Link
              to="/verify"
              className="inline-flex items-center gap-2 rounded-full bg-gradient-blue px-6 py-3 text-sm font-medium text-white shadow-lg blue-glow transition hover:opacity-95"
            >
              Start verification <ArrowRight className="h-4 w-4" />
            </Link>
            <a
              href="#how"
              className="inline-flex items-center gap-2 rounded-full border border-border bg-background px-6 py-3 text-sm font-medium text-foreground transition hover:bg-accent"
            >
              How it works
            </a>
          </div>
          <p className="mt-5 font-mono text-xs text-muted-foreground">
            ~4 min · camera required · encrypted in transit
          </p>
        </motion.div>
        <LiveAiDashboard />
      </div>
    </section>
  );
}

const AGENTS = [
  { name: "OCR Agent", detail: "extracting fields" },
  { name: "Liveness Agent", detail: "detecting real motion" },
  { name: "Face-Match Agent", detail: "cross-referencing ID photo" },
  { name: "Anti-Spoof Agent", detail: "screening for recaptures" },
];

function LiveAiDashboard() {
  const reduced = useReducedMotion();
  const [tick, setTick] = useState(0);
  useEffect(() => {
    if (reduced) return;
    const t = setInterval(() => setTick((x) => x + 1), 900);
    return () => clearInterval(t);
  }, [reduced]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: 0.1 }}
      className="relative"
    >
      <div className="rounded-3xl border border-border bg-card shadow-2xl blue-glow p-5">
        <div className="flex items-center justify-between border-b border-border pb-3">
          <div className="flex items-center gap-2">
            <span className="h-2 w-2 rounded-full bg-success animate-pulse" />
            <span className="font-mono text-xs uppercase tracking-wider text-muted-foreground">
              live monitor · session
            </span>
          </div>
          <span className="font-mono text-xs text-muted-foreground">
            {`#${(1000 + tick).toString(16).toUpperCase()}`}
          </span>
        </div>

        <div className="mt-4 grid grid-cols-5 gap-4">
          {/* ID silhouette with scan sweep */}
          <div className="col-span-2 relative overflow-hidden rounded-xl border border-border bg-muted/40 aspect-[3/4]">
            <div className="absolute inset-4 rounded-lg border-2 border-dashed border-primary/40" />
            <div className="absolute inset-6 space-y-2">
              <div className="h-2 w-16 rounded bg-primary/20" />
              <div className="h-2 w-24 rounded bg-primary/20" />
              <div className="mt-6 h-10 w-10 rounded-full bg-primary/20" />
              <div className="h-2 w-20 rounded bg-primary/20" />
              <div className="h-2 w-14 rounded bg-primary/20" />
            </div>
            <div className="absolute inset-x-0 top-0 h-1 bg-gradient-to-b from-primary/70 to-transparent animate-scan" />
            <div className="absolute bottom-2 left-2 right-2 flex items-center justify-between font-mono text-[10px] text-muted-foreground">
              <span>scan.jpg</span>
              <span>1280×720</span>
            </div>
          </div>

          {/* Agents panel */}
          <div className="col-span-3 space-y-2">
            {AGENTS.map((a, i) => {
              const phase = (tick + i) % 3; // 0 idle 1 analyzing 2 passed
              const label = phase === 0 ? "idle" : phase === 1 ? "analyzing" : "passed";
              const color =
                phase === 0
                  ? "bg-muted-foreground/40"
                  : phase === 1
                    ? "bg-primary animate-pulse"
                    : "bg-success";
              const pct = phase === 0 ? 4 : phase === 1 ? 62 : 96;
              return (
                <div key={a.name} className="rounded-lg border border-border bg-background p-2.5">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className={`h-2 w-2 rounded-full ${color}`} />
                      <span className="text-sm font-medium">{a.name}</span>
                    </div>
                    <span className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
                      {label}
                    </span>
                  </div>
                  <div className="mt-2 h-1 w-full overflow-hidden rounded-full bg-muted">
                    <motion.div
                      className="h-full bg-gradient-blue"
                      animate={{ width: `${pct}%` }}
                      transition={{ duration: 0.6 }}
                    />
                  </div>
                  <div className="mt-1.5 flex items-center justify-between font-mono text-[10px] text-muted-foreground">
                    <span>{a.detail}</span>
                    <span>{pct.toString().padStart(2, "0")}%</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="mt-4 grid grid-cols-3 gap-3 border-t border-border pt-3">
          {[
            { k: "trust", v: `${82 + (tick % 12)}%` },
            { k: "latency", v: `${120 + (tick % 40)}ms` },
            { k: "frames", v: `${1400 + tick}` },
          ].map((m) => (
            <div key={m.k}>
              <div className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
                {m.k}
              </div>
              <div className="font-mono text-lg font-semibold text-foreground">{m.v}</div>
            </div>
          ))}
        </div>
      </div>
    </motion.div>
  );
}

function TrustStrip() {
  const items = ["256-bit TLS", "0 third-party sharing", "GDPR-ready", "SOC 2 in progress"];
  return (
    <section className="border-y border-border bg-muted/30">
      <div className="mx-auto grid max-w-7xl grid-cols-2 gap-4 px-6 py-6 sm:grid-cols-4">
        {items.map((i) => (
          <div key={i} className="flex items-center gap-2 font-mono text-xs uppercase tracking-wider text-muted-foreground">
            <Lock className="h-3.5 w-3.5 text-primary" />
            {i}
          </div>
        ))}
      </div>
    </section>
  );
}

const PIPELINE = [
  { name: "Capture", icon: ScanLine },
  { name: "OCR Agent", icon: ScanLine },
  { name: "Liveness Agent", icon: Eye },
  { name: "Face-Match Agent", icon: Fingerprint },
  { name: "Anti-Spoof Agent", icon: MonitorSmartphone },
  { name: "Trust Score", icon: Gauge },
];

function AgentPipeline() {
  return (
    <section id="agents" className="mx-auto max-w-7xl px-6 py-24">
      <div className="mb-12 max-w-2xl">
        <p className="font-mono text-xs uppercase tracking-wider text-primary">The pipeline</p>
        <h2 className="mt-3 font-display text-4xl font-semibold tracking-tight">
          Six AI agents. One transparent score.
        </h2>
        <p className="mt-4 text-muted-foreground">
          Every mentor session runs through a chained pipeline. Each agent reports its
          confidence, and the final trust score is a weighted composite you can audit.
        </p>
      </div>

      <div className="hidden lg:flex items-stretch gap-2">
        {PIPELINE.map((p, i) => {
          const Icon = p.icon;
          return (
            <div key={p.name} className="flex flex-1 items-stretch gap-2">
              <div className="flex flex-1 flex-col items-center rounded-2xl border border-border bg-card p-5 text-center shadow-sm">
                <div className="grid h-10 w-10 place-items-center rounded-xl bg-primary/10 text-primary">
                  <Icon className="h-5 w-5" />
                </div>
                <div className="mt-3 font-medium">{p.name}</div>
                <div className="mt-1 font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
                  agent {i.toString().padStart(2, "0")}
                </div>
              </div>
              {i < PIPELINE.length - 1 && (
                <div className="my-auto w-6 h-0.5 animate-flow" />
              )}
            </div>
          );
        })}
      </div>

      <div className="grid gap-3 lg:hidden">
        {PIPELINE.map((p) => {
          const Icon = p.icon;
          return (
            <div key={p.name} className="flex items-center gap-3 rounded-xl border border-border bg-card p-4">
              <div className="grid h-10 w-10 place-items-center rounded-xl bg-primary/10 text-primary">
                <Icon className="h-5 w-5" />
              </div>
              <div className="font-medium">{p.name}</div>
            </div>
          );
        })}
      </div>
    </section>
  );
}

const BENTO = [
  {
    span: "lg:col-span-2 lg:row-span-2",
    title: "Real-time OCR",
    body: "Extracts every ID field as you scan — name, DOB, ID number, expiry — and cross-checks against the back.",
    metric: "~180ms / field",
    icon: ScanLine,
    hero: true,
  },
  {
    title: "Liveness detection",
    body: "Blink & head-turn heuristics catch static photos and pre-recorded loops.",
    metric: "98.4% recall",
    icon: Eye,
  },
  {
    title: "3-way face match",
    body: "ID photo, live face, and combo shot compared as embeddings.",
    metric: "cosine distance",
    icon: Fingerprint,
  },
  {
    title: "Screen-recapture guard",
    body: "Anti-spoof agent flags moiré, reflections, and glare patterns from screens.",
    metric: "spoof score 0–1",
    icon: MonitorSmartphone,
  },
  {
    title: "Duplicate detection",
    body: "Face and ID embeddings checked against every prior mentor session.",
    metric: "index in ms",
    icon: Users,
  },
  {
    title: "Trust scoring engine",
    body: "Weighted composite across every agent — the score the human reviewer sees.",
    metric: "0 – 100",
    icon: Gauge,
  },
];

function CapabilitiesBento() {
  return (
    <section className="mx-auto max-w-7xl px-6 py-24">
      <div className="mb-12 max-w-2xl">
        <p className="font-mono text-xs uppercase tracking-wider text-primary">Capabilities</p>
        <h2 className="mt-3 font-display text-4xl font-semibold tracking-tight">
          The ML stack, in plain sight.
        </h2>
      </div>
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4 lg:auto-rows-[220px]">
        {BENTO.map((b) => {
          const Icon = b.icon;
          return (
            <div
              key={b.title}
              className={`group relative overflow-hidden rounded-2xl border border-border bg-card p-6 shadow-sm transition hover:shadow-md ${b.span ?? ""}`}
            >
              <div className="flex items-start justify-between">
                <div className="grid h-10 w-10 place-items-center rounded-xl bg-primary/10 text-primary">
                  <Icon className="h-5 w-5" />
                </div>
                <span className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
                  {b.metric}
                </span>
              </div>
              <h3 className={`mt-4 font-display font-semibold ${b.hero ? "text-2xl" : "text-lg"}`}>
                {b.title}
              </h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{b.body}</p>
              {b.hero && (
                <div className="mt-6 space-y-2 font-mono text-xs">
                  {[
                    ["name", "Aarav Sharma"],
                    ["dob", "1998-04-12"],
                    ["id_number", "MEN-4821-77X"],
                    ["expiry", "2031-04-11"],
                  ].map(([k, v]) => (
                    <div key={k} className="flex items-center justify-between rounded-md border border-border bg-background px-2.5 py-1.5">
                      <span className="text-muted-foreground">{k}</span>
                      <span className="text-foreground">{v}</span>
                    </div>
                  ))}
                </div>
              )}
              <div className="pointer-events-none absolute -bottom-24 -right-24 h-48 w-48 rounded-full bg-primary-glow/10 blur-3xl opacity-0 transition group-hover:opacity-100" />
            </div>
          );
        })}
      </div>
    </section>
  );
}

const STEPS = [
  { n: "01", title: "Scan ID front", body: "Live camera with a card outline; AI reads and validates every field." },
  { n: "02", title: "Tilt for hologram", body: "Slowly tilt left and right; anti-spoof agent verifies genuine card depth." },
  { n: "03", title: "Scan ID back", body: "Same live pipeline; template and layout are cross-verified." },
  { n: "04", title: "Bot-check", body: "Quick arithmetic challenge to defeat automated agents." },
  { n: "05", title: "Face + liveness", body: "Blink and head turns confirm you're real and match the ID photo." },
];

function HowItWorks() {
  return (
    <section id="how" className="border-t border-border bg-muted/20">
      <div className="mx-auto max-w-7xl px-6 py-24">
        <div className="mb-12 max-w-2xl">
          <p className="font-mono text-xs uppercase tracking-wider text-primary">How it works</p>
          <h2 className="mt-3 font-display text-4xl font-semibold tracking-tight">
            Five guided steps. Real timers, no rush.
          </h2>
        </div>
        <ol className="grid gap-4 md:grid-cols-5">
          {STEPS.map((s) => (
            <li key={s.n} className="rounded-2xl border border-border bg-background p-5">
              <div className="font-mono text-xs text-primary">{s.n}</div>
              <div className="mt-2 font-display font-semibold">{s.title}</div>
              <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{s.body}</p>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}

function PrivacyStrip() {
  const items = [
    { icon: Lock, t: "No cloud training on your face." },
    { icon: Cpu, t: "Frames purged after decision." },
    { icon: ShieldCheck, t: "Every check auditable." },
  ];
  return (
    <section id="privacy" className="mx-auto max-w-7xl px-6 py-20">
      <div className="grid gap-4 sm:grid-cols-3">
        {items.map(({ icon: Icon, t }) => (
          <div key={t} className="flex items-center gap-3 rounded-xl border border-border bg-card p-5">
            <Icon className="h-5 w-5 text-primary" />
            <span className="text-sm font-medium">{t}</span>
          </div>
        ))}
      </div>
    </section>
  );
}

function FinalCta() {
  return (
    <section className="relative overflow-hidden">
      <div className="pointer-events-none absolute inset-0 bg-gradient-to-br from-primary/8 via-transparent to-primary-glow/10" />
      <div className="mx-auto max-w-4xl px-6 py-24 text-center">
        <h2 className="font-display text-4xl font-semibold tracking-tight sm:text-5xl">
          Ready when your mentor is.
        </h2>
        <p className="mx-auto mt-4 max-w-xl text-muted-foreground">
          Under five minutes, camera-only, no external accounts.
        </p>
        <div className="mt-8">
          <Link
            to="/verify"
            className="inline-flex items-center gap-2 rounded-full bg-gradient-blue px-7 py-3.5 text-base font-medium text-white shadow-xl blue-glow transition hover:opacity-95"
          >
            Start verification <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="border-t border-border">
      <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-3 px-6 py-8 text-sm text-muted-foreground sm:flex-row">
        <div className="flex items-center gap-2">
          <div className="grid h-6 w-6 place-items-center rounded-md bg-gradient-blue text-white">
            <ShieldCheck className="h-3 w-3" />
          </div>
          <span className="font-display font-semibold text-foreground">ConnectLive</span>
          <span className="font-mono text-xs">v1.0</span>
        </div>
        <div>© {new Date().getFullYear()} ConnectLive. All rights reserved.</div>
      </div>
    </footer>
  );
}
