// /verify/result/:id — final verdict + 5 score rings + per-side check rows.
import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo } from "react";
import { motion } from "framer-motion";
import { ShieldCheck, Check, X, Download, ArrowRight, RefreshCw } from "lucide-react";
import type { CheckRow, Scores, Verdict, VerificationResult } from "../verification/types";

export const Route = createFileRoute("/verify/result/$id")({
  head: () => ({
    meta: [
      { title: "Verification result — ConnectLive" },
      { name: "description", content: "Your ConnectLive mentor verification result." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: ResultPage,
});

function ResultPage() {
  const { id } = Route.useParams();
  const result = useMemo<VerificationResult | null>(() => {
    if (typeof window === "undefined") return null;
    const raw = sessionStorage.getItem(`cl:result:${id}`);
    if (!raw) return null;
    try { return JSON.parse(raw) as VerificationResult; } catch { return null; }
  }, [id]);

  if (!result) {
    return (
      <div className="grid min-h-screen place-items-center bg-background px-6">
        <div className="text-center">
          <h1 className="font-display text-2xl font-semibold">No result found</h1>
          <p className="mt-2 text-muted-foreground">This verification session isn't available anymore.</p>
          <Link to="/verify" className="mt-6 inline-flex items-center gap-2 rounded-full bg-gradient-blue px-5 py-2.5 text-sm font-medium text-white">
            Start a new one <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <TopBar />
      <main className="mx-auto max-w-5xl px-4 pb-24 pt-6">
        <VerdictBanner verdict={result.verdict} reason={result.reason} />
        <ScoreGrid scores={result.scores} hideDetail={result.verdict === "review"} />

        {result.verdict !== "review" && (
          <div className="mt-8 grid gap-4 lg:grid-cols-3">
            <ChecksCard title="ID — Front" rows={result.frontChecks} />
            <ChecksCard title="ID — Back" rows={result.backChecks} />
            <ChecksCard title="Face" rows={result.faceChecks} />
          </div>
        )}

        <div className="mt-8 grid gap-4 lg:grid-cols-2">
          <OcrCard fields={result.ocrFields} />
          <CapturesCard captures={result.captures} />
        </div>

        <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
          <Link
            to="/verify"
            className="inline-flex items-center gap-2 rounded-full bg-gradient-blue px-6 py-3 text-sm font-medium text-white shadow-lg blue-glow"
          >
            <RefreshCw className="h-4 w-4" /> Start new verification
          </Link>
          <a
            download={`connectlive-${result.id}.json`}
            href={`data:application/json;charset=utf-8,${encodeURIComponent(JSON.stringify(result, null, 2))}`}
            className="inline-flex items-center gap-2 rounded-full border border-border bg-background px-6 py-3 text-sm font-medium text-foreground hover:bg-accent"
          >
            <Download className="h-4 w-4" /> Download report JSON
          </a>
        </div>
      </main>
    </div>
  );
}

function TopBar() {
  return (
    <header className="border-b border-border/60 bg-background/80 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-5xl items-center justify-between px-4">
        <Link to="/" className="flex items-center gap-2">
          <div className="grid h-8 w-8 place-items-center rounded-lg bg-gradient-blue text-white">
            <ShieldCheck className="h-4 w-4" />
          </div>
          <span className="font-display text-lg font-semibold tracking-tight">ConnectLive</span>
        </Link>
        <span className="font-mono text-xs uppercase tracking-wider text-muted-foreground">Result</span>
      </div>
    </header>
  );
}

function VerdictBanner({ verdict, reason }: { verdict: Verdict; reason: string }) {
  const map = {
    approved: {
      title: "You're verified!",
      tone: "bg-success/10 border-success/30 text-success",
      icon: Check,
    },
    review: {
      title: "Under manual review",
      tone: "bg-warning/10 border-warning/30 text-warning",
      icon: RefreshCw,
    },
    rejected: {
      title: "Verification couldn't complete",
      tone: "bg-danger/10 border-danger/30 text-danger",
      icon: X,
    },
  }[verdict];
  const Icon = map.icon;
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      className={`rounded-2xl border p-6 ${map.tone}`}
    >
      <div className="flex items-start gap-4">
        <div className="grid h-11 w-11 place-items-center rounded-xl bg-background">
          <Icon className="h-5 w-5" />
        </div>
        <div>
          <h1 className="font-display text-2xl font-semibold text-foreground">{map.title}</h1>
          <p className="mt-1 text-sm text-muted-foreground">{reason}</p>
        </div>
      </div>
    </motion.div>
  );
}

function ScoreGrid({ scores, hideDetail }: { scores: Scores; hideDetail: boolean }) {
  const items = [
    { key: "liveness", label: "Liveness", value: scores.liveness },
    { key: "faceMatch", label: "Face Match", value: scores.faceMatch },
    { key: "documentAuthenticity", label: "Document Authenticity", value: scores.documentAuthenticity },
    { key: "dataMatch", label: "Data Match", value: scores.dataMatch },
  ];
  return (
    <div className="mt-8 grid gap-6 lg:grid-cols-[1.2fr_2fr]">
      <div className="rounded-2xl border border-border bg-card p-6 text-center">
        <div className="font-mono text-[10px] uppercase tracking-wider text-primary">Overall Trust Score</div>
        <Ring value={scores.overallTrust} size={200} thick={14} hero />
        <div className="mt-2 text-xs text-muted-foreground">
          weighted composite across all AI agents
        </div>
      </div>
      <div className="grid grid-cols-2 gap-4">
        {items.map((s) => (
          <div key={s.key} className="rounded-2xl border border-border bg-card p-5 flex items-center gap-4">
            <Ring value={s.value} size={72} thick={7} />
            <div>
              <div className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
                {s.label}
              </div>
              <div className="font-display text-xl font-semibold">
                {hideDetail ? "—" : `${s.value}%`}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function Ring({ value, size, thick, hero = false }: { value: number; size: number; thick: number; hero?: boolean }) {
  const r = (size - thick) / 2;
  const c = 2 * Math.PI * r;
  const off = c - (value / 100) * c;
  return (
    <div className="relative mx-auto" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} stroke="var(--muted)" strokeWidth={thick} fill="none" />
        <motion.circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          stroke="url(#g)"
          strokeWidth={thick}
          fill="none"
          strokeLinecap="round"
          strokeDasharray={c}
          initial={{ strokeDashoffset: c }}
          animate={{ strokeDashoffset: off }}
          transition={{ duration: 1.1, ease: "easeOut" }}
        />
        <defs>
          <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#2563eb" />
            <stop offset="100%" stopColor="#60a5fa" />
          </linearGradient>
        </defs>
      </svg>
      <div className="absolute inset-0 grid place-items-center">
        <div className={`font-mono font-semibold ${hero ? "text-4xl" : "text-lg"}`}>
          {value}
          <span className="text-muted-foreground text-sm">%</span>
        </div>
      </div>
    </div>
  );
}

function ChecksCard({ title, rows }: { title: string; rows: CheckRow[] }) {
  return (
    <div className="rounded-2xl border border-border bg-card p-5">
      <h3 className="font-display text-lg font-semibold">{title}</h3>
      <ul className="mt-3 space-y-2">
        {rows.map((r) => (
          <li key={r.id} className="flex items-center justify-between rounded-lg border border-border bg-background p-3">
            <div className="flex items-center gap-2">
              {r.passed ? (
                <Check className="h-4 w-4 text-success" />
              ) : (
                <X className="h-4 w-4 text-danger" />
              )}
              <span className="text-sm">{r.label}</span>
            </div>
            <span className="font-mono text-xs text-muted-foreground">
              {Math.round(r.confidence * 100)}%
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
}

function OcrCard({ fields }: { fields: Record<string, string> }) {
  return (
    <div className="rounded-2xl border border-border bg-card p-5">
      <h3 className="font-display text-lg font-semibold">Extracted ID fields</h3>
      <div className="mt-3 space-y-2 font-mono text-sm">
        {Object.entries(fields).map(([k, v]) => (
          <div key={k} className="flex items-center justify-between rounded-lg border border-border bg-background px-3 py-2">
            <span className="text-muted-foreground">{k}</span>
            <span className="text-foreground">{v}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function CapturesCard({ captures }: { captures: Record<string, string> }) {
  const entries = Object.entries(captures).filter(([, v]) => !!v);
  return (
    <div className="rounded-2xl border border-border bg-card p-5">
      <h3 className="font-display text-lg font-semibold">Captured frames</h3>
      {entries.length === 0 ? (
        <div className="mt-3 text-sm text-muted-foreground">No frames captured.</div>
      ) : (
        <div className="mt-3 grid grid-cols-3 gap-2">
          {entries.map(([k, v]) => (
            <div key={k} className="rounded-lg border border-border overflow-hidden">
              <img src={v} alt={k} className="aspect-video w-full object-cover" />
              <div className="font-mono text-[10px] px-1.5 py-1 text-muted-foreground border-t border-border">
                {k}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
