// Live camera stage: <video> + transparent SVG overlay + hidden sampling canvas.
// Owns the MediaStream lifecycle and reports per-frame sharpness upward.
import { useEffect, useRef, useState } from "react";

export type FacingMode = "environment" | "user";

interface Props {
  facingMode: FacingMode;
  overlay?: React.ReactNode;
  onSharpness?: (v: number) => void;
  onCanvasReady?: (canvas: HTMLCanvasElement) => void;
  // [1/15] The old flow only ever handed callers the tiny 320x180 sampling
  // canvas, which is why captures were blurry — real captures now need the
  // actual <video> element so they can grab it at full native resolution.
  onVideoReady?: (video: HTMLVideoElement) => void;
}

export function CameraStage({ facingMode, overlay, onSharpness, onCanvasReady, onVideoReady }: Props) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [error, setError] = useState<string | null>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let stream: MediaStream | null = null;
    let cancelled = false;
    async function start() {
      try {
        stream = await navigator.mediaDevices.getUserMedia({
          video: {
            facingMode: { ideal: facingMode },
            width: { ideal: 1280 },
            height: { ideal: 720 },
          },
          audio: false,
        });
        if (cancelled) { stream.getTracks().forEach((t) => t.stop()); return; }
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          await videoRef.current.play().catch(() => {});
          setReady(true);
          if (canvasRef.current && onCanvasReady) onCanvasReady(canvasRef.current);
          if (videoRef.current && onVideoReady) onVideoReady(videoRef.current);
        }
      } catch (e: unknown) {
        setError(e instanceof Error ? e.message : "camera unavailable");
      }
    }
    start();
    return () => {
      cancelled = true;
      if (stream) stream.getTracks().forEach((t) => t.stop());
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [facingMode]);

  useEffect(() => {
    if (!ready) return;
    let raf = 0;
    let last = 0;
    const step = (t: number) => {
      raf = requestAnimationFrame(step);
      if (t - last < 100) return;
      last = t;
      const v = videoRef.current;
      const c = canvasRef.current;
      if (!v || !c || v.videoWidth === 0) return;
      c.width = 320;
      c.height = 180;
      const ctx = c.getContext("2d");
      if (!ctx) return;
      ctx.drawImage(v, 0, 0, c.width, c.height);
      if (onSharpness) onSharpness(estimateSharpness(ctx, c.width, c.height));
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [ready, onSharpness]);

  return (
    <div className="relative w-full aspect-[9/16] sm:aspect-video max-h-[70vh] rounded-2xl overflow-hidden bg-neutral-950 border border-border shadow-xl">
      <video
        ref={videoRef}
        muted
        autoPlay
        playsInline
        className="absolute inset-0 h-full w-full object-cover"
        style={{ transform: facingMode === "user" ? "scaleX(-1)" : undefined }}
      />
      <canvas ref={canvasRef} className="hidden" />
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_55%,rgba(0,0,0,0.5)_100%)]" />
      {overlay && <div className="pointer-events-none absolute inset-0">{overlay}</div>}
      {!ready && !error && (
        <div className="absolute inset-0 flex items-center justify-center text-white/80 text-sm font-mono">
          starting camera…
        </div>
      )}
      {error && (
        <div className="absolute inset-0 flex items-center justify-center text-white text-sm font-mono px-6 text-center bg-black/60">
          camera error: {error}
        </div>
      )}
    </div>
  );
}

// [1/15] Kept for callers that only have the small sampling canvas (e.g. the
// legacy mock service). Real captures should prefer captureVideoSnapshot().
export function captureCanvasSnapshot(source: HTMLCanvasElement): string {
  const out = document.createElement("canvas");
  out.width = 640;
  out.height = 360;
  const octx = out.getContext("2d");
  if (!octx) return "";
  octx.drawImage(source, 0, 0, out.width, out.height);
  return out.toDataURL("image/jpeg", 0.82);
}

// [1/15] The actual capture bug fix: draw straight from the live <video> at
// its native resolution (e.g. 1280x720, whatever the camera negotiated),
// not the down-sampled 320x180 canvas used only for sharpness scoring.
// Quality bumped 0.82 -> 0.92 since we're no longer throwing resolution away.
export function captureVideoSnapshot(video: HTMLVideoElement, mirror = false): string {
  const w = video.videoWidth || 1280;
  const h = video.videoHeight || 720;
  if (w === 0 || h === 0) return "";
  const out = document.createElement("canvas");
  out.width = w;
  out.height = h;
  const ctx = out.getContext("2d");
  if (!ctx) return "";
  if (mirror) {
    ctx.translate(w, 0);
    ctx.scale(-1, 1);
  }
  ctx.drawImage(video, 0, 0, w, h);
  return out.toDataURL("image/jpeg", 0.92);
}

// [2/15,3/15,4/15,5/15] Scores a full-resolution frame's sharpness + exposure
// so the auto-capture sampler can pick the best of many frames. Reuses the
// same Laplacian-variance idea as estimateSharpness but also penalizes
// frames that are too dark/blown-out, which the old preview-only scorer
// never accounted for.
export function scoreVideoFrame(video: HTMLVideoElement): number {
  const w = video.videoWidth, h = video.videoHeight;
  if (!w || !h) return 0;
  const c = document.createElement("canvas");
  const sw = 320, sh = Math.round((h / w) * 320);
  c.width = sw; c.height = sh;
  const ctx = c.getContext("2d");
  if (!ctx) return 0;
  ctx.drawImage(video, 0, 0, sw, sh);
  const sharpness = estimateSharpness(ctx, sw, sh);
  const { data } = ctx.getImageData(0, 0, sw, sh);
  let lumaSum = 0;
  for (let i = 0; i < data.length; i += 4) {
    lumaSum += data[i] * 0.299 + data[i + 1] * 0.587 + data[i + 2] * 0.114;
  }
  const meanLuma = lumaSum / (data.length / 4);
  // Penalize frames that are too dark (<40) or blown out (>230).
  const exposurePenalty = meanLuma < 40 ? (40 - meanLuma) : meanLuma > 230 ? (meanLuma - 230) : 0;
  return Math.max(0, sharpness - exposurePenalty * 1.5);
}

function estimateSharpness(ctx: CanvasRenderingContext2D, w: number, h: number) {
  const { data } = ctx.getImageData(0, 0, w, h);
  let sum = 0, sumSq = 0, n = 0;
  for (let y = 1; y < h - 1; y += 2) {
    for (let x = 1; x < w - 1; x += 2) {
      const i = (y * w + x) * 4;
      const g = data[i] * 0.299 + data[i + 1] * 0.587 + data[i + 2] * 0.114;
      const gr = data[i + 4] * 0.299 + data[i + 5] * 0.587 + data[i + 6] * 0.114;
      const gd = data[i + w * 4] * 0.299 + data[i + w * 4 + 1] * 0.587 + data[i + w * 4 + 2] * 0.114;
      const d = Math.abs(g - gr) + Math.abs(g - gd);
      sum += d; sumSq += d * d; n++;
    }
  }
  const mean = sum / n;
  const varr = sumSq / n - mean * mean;
  return Math.min(100, Math.max(0, Math.round(Math.sqrt(varr) * 3)));
}
