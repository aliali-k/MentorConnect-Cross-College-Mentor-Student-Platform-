// Central timing + retry configuration for the verification flow.
// All durations live here so the whole flow can be re-tuned in one place.

export const TIMING = {
  FRONT_SCAN_MS: 32000,
  TILT_MS: 38000,
  BACK_SCAN_MS: 32000,
  PUZZLE_MS: 42000,
  FACE_COMBO_MS: 30000,
  // [5/15] new auto-only Face + ID combo phase.
  ID_COMBO_MS: 26000,
  LIVENESS_MS: 28000,
  PROCESSING_MS: 8000,
  SESSION_TOTAL_CAP_MS: 6 * 60 * 1000,
  SUB_STATUS_MS: 3500,
  WS_CONNECT_TIMEOUT_MS: 3000,

  // [2/15, 3/15, 4/15, 5/15] auto-capture sampling window: after the manual
  // shot (or immediately, for the auto-only combo step) we sample frames for
  // this long and keep whichever scored best on sharpness/lighting.
  AUTO_CAPTURE_INSTRUCTION_MS: 1800,
  AUTO_CAPTURE_SAMPLE_MS: 10000,
  AUTO_CAPTURE_SAMPLE_INTERVAL_MS: 220,
} as const;

export const LIMITS = {
  PUZZLE_ATTEMPTS: 3,
  PUZZLE_QUESTIONS: 3,
  CAPTURE_RETRIES: 2,
} as const;

export const SUB_STATUSES = {
  front_scan: [
    "Reading text",
    "Checking image quality",
    "Verifying watermark",
    "Checking for edits",
  ],
  back_scan: [
    "Reading text",
    "Checking image quality",
    "Verifying watermark",
    "Checking for edits",
  ],
  face_combo: ["Comparing with ID photo", "Checking liveness"],
  id_combo: ["Detecting face and card", "Checking distance and framing", "Confirming it's not a screen or printout"],
  processing: [
    "Verifying document authenticity",
    "Cross-checking data fields",
    "Scanning for duplicate identities",
    "Finalizing your trust score",
  ],
} as const;

export const PHASE_LABELS: Record<string, string> = {
  front_scan: "ID card — front",
  tilt: "Tilt for hologram check",
  back_scan: "ID card — back",
  puzzle: "Quick bot check",
  face_combo: "Live face capture",
  id_combo: "Face + ID combo check",
  liveness: "Liveness actions",
  processing: "Final review",
};

// [13/15] Copy for the two-step auto-capture UX, shared by front/back/face
// and reused (with no manual step) for the id_combo phase.
export const AUTO_CAPTURE_COPY: Record<string, { instruction: string; sampling: string }> = {
  front_manual: { instruction: "We'll auto-capture a backup shot now — hold steady.", sampling: "Sampling the sharpest frame…" },
  back_manual: { instruction: "We'll auto-capture a backup shot now — hold steady.", sampling: "Sampling the sharpest frame…" },
  face_manual: { instruction: "We'll auto-capture a backup shot now — hold steady.", sampling: "Sampling the best frame…" },
  face_id_combo: { instruction: "Hold your ID card next to your face — we'll auto-capture in a moment.", sampling: "Checking face + card framing…" },
};
