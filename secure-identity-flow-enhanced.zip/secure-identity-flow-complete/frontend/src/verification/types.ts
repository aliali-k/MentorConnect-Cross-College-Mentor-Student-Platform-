// Full typed contract for the mentor verification flow.
// Every message shape here is what the mock service emits AND what the real
// WebSocket backend must implement — the UI never sees anything else.

export type Side = "front" | "back";
export type FacingMode = "environment" | "user";

export type Phase =
  | "welcome"
  | "front_scan"
  | "tilt"
  | "back_scan"
  | "puzzle"
  | "face_combo"
  | "id_combo"
  | "liveness"
  | "processing"
  | "complete";

export const PHASE_ORDER: Phase[] = [
  "front_scan",
  "tilt",
  "back_scan",
  "puzzle",
  "face_combo",
  "id_combo",
  "liveness",
  "processing",
];

export type ConnectionStatus =
  | "idle"
  | "connecting"
  | "live"
  | "processing"
  | "done"
  | "error";

// [15/15] Standardized, consistent naming across every manual/auto pair.
// front_final/back_final/face_best are gone — replaced by explicit *_manual
// and *_auto kinds, plus the new auto-only face_id_combo capture.
export type CaptureKind =
  | "front_manual"
  | "front_auto"
  | "back_manual"
  | "back_auto"
  | "face_manual"
  | "face_auto"
  | "face_id_combo"
  | "tilt_frame_1"
  | "tilt_frame_2";

export type MovementPrompt =
  | "blink"
  | "turn_left"
  | "turn_right"
  | "hold_steady";

// ------- Client -> Server -------
export type ClientMessage =
  | { type: "session_start"; sessionId: string; deviceId: string }
  | { type: "begin" }
  // [7/15] score travels with every capture so the server can pick whichever
  // of the manual/auto pair actually scored best for OCR/face-match input.
  | { type: "capture"; kind: CaptureKind; dataUrl: string; score?: number }
  | { type: "puzzle_answer"; index: number; answer: number }
  | { type: "frame_sharpness"; value: number }
  | { type: "abort" };

// ------- Server -> Client -------
export type ServerMessage =
  | { type: "phase_start"; phase: Phase; durationMs: number }
  | { type: "phase_sub_status"; label: string; index: number; total: number }
  | { type: "hint"; message: string; level?: "info" | "warn" | "error" }
  | { type: "movement_prompt"; prompt: MovementPrompt }
  | { type: "puzzle_question"; index: number; total: number; text: string }
  | { type: "puzzle_result"; correct: boolean; attemptsLeft: number }
  | { type: "capture_progress"; ms: number; totalMs: number; sharpness: number; seq: number }
  | { type: "captured"; kind: CaptureKind; dataUrl: string }
  | { type: "retry_required"; reason: string }
  | { type: "rate_limited"; retryAfterSec: number }
  | { type: "session_end"; result: VerificationResult };

export type EngineEvent = ServerMessage | { type: "connection"; status: ConnectionStatus };

export interface CheckRow {
  id: string;
  label: string;
  passed: boolean;
  confidence: number; // 0..1
  detail?: string;
}

export interface Scores {
  liveness: number;         // 0..100
  faceMatch: number;
  documentAuthenticity: number;
  dataMatch: number;
  overallTrust: number;
}

export type Verdict = "approved" | "review" | "rejected";

export interface VerificationResult {
  id: string;
  createdAt: number;
  verdict: Verdict;
  reason: string;
  scores: Scores;
  frontChecks: CheckRow[];
  backChecks: CheckRow[];
  faceChecks: CheckRow[];
  ocrFields: Record<string, string>;
  captures: Partial<Record<CaptureKind, string>>;
}
