// Central Zustand store: holds every piece of live verification state.
// Every phase component reads/writes here; no prop-drilling anywhere.
import { create } from "zustand";
import type {
  CaptureKind,
  CheckRow,
  ConnectionStatus,
  Phase,
  Scores,
  Verdict,
  VerificationResult,
} from "./types";

interface State {
  sessionId: string | null;
  phase: Phase;
  subStatus: { label: string; index: number; total: number } | null;
  connectionStatus: ConnectionStatus;
  captures: Partial<Record<CaptureKind, string>>;
  frontChecks: CheckRow[];
  backChecks: CheckRow[];
  faceChecks: CheckRow[];
  scores: Scores | null;
  verdict: Verdict | null;
  ocrFields: Record<string, string>;
  hint: { message: string; level: "info" | "warn" | "error" } | null;
  error: string | null;
  puzzleQuestion: { index: number; total: number; text: string } | null;
  puzzleAttemptsLeft: number;
  movementPrompt: string | null;
  captureProgress: { ms: number; totalMs: number; sharpness: number } | null;

  setPhase: (p: Phase) => void;
  setSubStatus: (s: State["subStatus"]) => void;
  setConnectionStatus: (c: ConnectionStatus) => void;
  addCapture: (kind: CaptureKind, dataUrl: string) => void;
  setHint: (h: State["hint"]) => void;
  setError: (e: string | null) => void;
  setPuzzleQuestion: (q: State["puzzleQuestion"]) => void;
  setPuzzleAttemptsLeft: (n: number) => void;
  setMovementPrompt: (p: string | null) => void;
  setCaptureProgress: (p: State["captureProgress"]) => void;
  applyResult: (r: VerificationResult) => void;
  reset: (sessionId: string) => void;
}

export const useVerificationStore = create<State>((set) => ({
  sessionId: null,
  phase: "welcome",
  subStatus: null,
  connectionStatus: "idle",
  captures: {},
  frontChecks: [],
  backChecks: [],
  faceChecks: [],
  scores: null,
  verdict: null,
  ocrFields: {},
  hint: null,
  error: null,
  puzzleQuestion: null,
  puzzleAttemptsLeft: 3,
  movementPrompt: null,
  captureProgress: null,

  setPhase: (phase) => set({ phase, subStatus: null }),
  setSubStatus: (subStatus) => set({ subStatus }),
  setConnectionStatus: (connectionStatus) => set({ connectionStatus }),
  addCapture: (kind, dataUrl) =>
    set((s) => ({ captures: { ...s.captures, [kind]: dataUrl } })),
  setHint: (hint) => set({ hint }),
  setError: (error) => set({ error }),
  setPuzzleQuestion: (puzzleQuestion) => set({ puzzleQuestion }),
  setPuzzleAttemptsLeft: (puzzleAttemptsLeft) => set({ puzzleAttemptsLeft }),
  setMovementPrompt: (movementPrompt) => set({ movementPrompt }),
  setCaptureProgress: (captureProgress) => set({ captureProgress }),
  applyResult: (r) =>
    set({
      scores: r.scores,
      verdict: r.verdict,
      frontChecks: r.frontChecks,
      backChecks: r.backChecks,
      faceChecks: r.faceChecks,
      ocrFields: r.ocrFields,
      captures: r.captures,
    }),
  reset: (sessionId) =>
    set({
      sessionId,
      phase: "welcome",
      subStatus: null,
      connectionStatus: "idle",
      captures: {},
      frontChecks: [],
      backChecks: [],
      faceChecks: [],
      scores: null,
      verdict: null,
      ocrFields: {},
      hint: null,
      error: null,
      puzzleQuestion: null,
      puzzleAttemptsLeft: 3,
      movementPrompt: null,
      captureProgress: null,
    }),
}));
