// Single service layer for the entire verification flow.
// Two implementations behind one interface:
//   - MockVerificationService: drives the flow client-side with realistic delays.
//   - WsVerificationService: connects to VITE_VERIFY_WS_URL and forwards frames.
// Swap backends by setting VITE_VERIFY_WS_URL; if unreachable, factory falls back to mock.
import type {
  CaptureKind,
  EngineEvent,
  ServerMessage,
  VerificationResult,
} from "../verification/types";
import { TIMING, SUB_STATUSES, LIMITS } from "../verification/config";

type Listener = (e: EngineEvent) => void;

export interface VerificationService {
  connect(sessionId: string): Promise<void>;
  begin(): void;
  // [7/15] score is optional so callers that don't compute one (mock, or a
  // single manual-only shot) keep working unchanged.
  sendCapture(kind: CaptureKind, dataUrl: string, score?: number): void;
  submitPuzzleAnswer(index: number, answer: number): void;
  updateFrameSharpness(value: number): void;
  abort(): void;
  on(listener: Listener): () => void;
  disconnect(): void;
}

class Emitter {
  private listeners = new Set<Listener>();
  private lastProgressSeq = -1;
  on(l: Listener) {
    this.listeners.add(l);
    return () => this.listeners.delete(l);
  }
  emit(e: EngineEvent) {
    // Debounce/skip stale capture_progress events.
    if (e.type === "capture_progress") {
      if (e.seq < this.lastProgressSeq) return;
      this.lastProgressSeq = e.seq;
    }
    this.listeners.forEach((l) => l(e));
  }
}

// [15/15] Persistent per-browser device id, kept separate from the random
// per-session id. This is what makes real anti-spam rate limiting possible —
// see #15 in the backend writeup.
export function getOrCreateDeviceId(): string {
  const KEY = "cl:deviceId";
  try {
    let id = localStorage.getItem(KEY);
    if (!id) {
      id = crypto.randomUUID();
      localStorage.setItem(KEY, id);
    }
    return id;
  } catch {
    // localStorage unavailable (private mode, etc.) — fall back to a
    // per-tab id; server-side IP fallback still applies in that case.
    return crypto.randomUUID();
  }
}

// ---------- Mock ----------
class MockVerificationService implements VerificationService {
  private emitter = new Emitter();
  private sessionId = "";
  private aborted = false;
  private puzzleAnswers: number[] = [];
  private puzzleIndex = 0;
  private puzzleAttempts = LIMITS.PUZZLE_ATTEMPTS;

  async connect(sessionId: string) {
    this.sessionId = sessionId;
    this.emitter.emit({ type: "connection", status: "connecting" });
    await this.wait(400);
    this.emitter.emit({ type: "connection", status: "live" });
  }

  on(l: Listener) { return this.emitter.on(l); }
  disconnect() { this.aborted = true; }
  abort() { this.aborted = true; this.emitter.emit({ type: "connection", status: "error" }); }
  sendCapture(_kind: CaptureKind, _dataUrl: string, _score?: number) { /* mock stores on client side */ }
  updateFrameSharpness(_v: number) { /* mock ignores */ }

  submitPuzzleAnswer(index: number, answer: number) {
    const expected = this.puzzleAnswers[index];
    const correct = answer === expected;
    if (!correct) this.puzzleAttempts--;
    this.emitter.emit({
      type: "puzzle_result",
      correct,
      attemptsLeft: this.puzzleAttempts,
    });
    if (correct) this.puzzleIndex++;
  }

  begin() {
    void this.run();
  }

  private async run() {
    await this.runScanPhase("front_manual", TIMING.FRONT_SCAN_MS);
    await this.runTilt();
    await this.runScanPhase("back_manual", TIMING.BACK_SCAN_MS);
    await this.runPuzzle();
    await this.runFaceCombo();
    await this.runIdCombo();
    await this.runLiveness();
    await this.runProcessing();
    this.emitter.emit({
      type: "session_end",
      result: this.buildResult(),
    });
    this.emitter.emit({ type: "connection", status: "done" });
  }

  private async runScanPhase(kind: "front_manual" | "back_manual", durationMs: number) {
    if (this.aborted) return;
    const phase = kind === "front_manual" ? "front_scan" : "back_scan";
    this.emit({ type: "phase_start", phase, durationMs });
    await this.wait(3000);
    const subs = SUB_STATUSES[phase];
    for (let i = 0; i < subs.length; i++) {
      if (this.aborted) return;
      this.emit({
        type: "phase_sub_status",
        label: subs[i],
        index: i + 1,
        total: subs.length,
      });
      await this.wait(TIMING.SUB_STATUS_MS);
    }
  }

  private async runTilt() {
    if (this.aborted) return;
    this.emit({ type: "phase_start", phase: "tilt", durationMs: TIMING.TILT_MS });
    await this.wait(6000);
  }

  private async runPuzzle() {
    if (this.aborted) return;
    this.emit({ type: "phase_start", phase: "puzzle", durationMs: TIMING.PUZZLE_MS });
    this.puzzleAnswers = [];
    this.puzzleIndex = 0;
    for (let i = 0; i < LIMITS.PUZZLE_QUESTIONS; i++) {
      const a = 3 + Math.floor(Math.random() * 12);
      const b = 2 + Math.floor(Math.random() * 9);
      const op: "+" | "-" | "×" = ["+", "-", "×"][Math.floor(Math.random() * 3)] as never;
      const ans = op === "+" ? a + b : op === "-" ? a - b : a * b;
      this.puzzleAnswers.push(ans);
    }
    this.emitCurrentPuzzleQ();
    const start = Date.now();
    while (
      this.puzzleIndex < LIMITS.PUZZLE_QUESTIONS &&
      this.puzzleAttempts > 0 &&
      Date.now() - start < TIMING.PUZZLE_MS &&
      !this.aborted
    ) {
      await this.wait(300);
      if (this.puzzleIndex < LIMITS.PUZZLE_QUESTIONS) {
        this.emitCurrentPuzzleQ();
      }
    }
  }

  private lastEmittedQ = -1;
  private emitCurrentPuzzleQ() {
    if (this.puzzleIndex === this.lastEmittedQ) return;
    this.lastEmittedQ = this.puzzleIndex;
    if (this.puzzleIndex >= LIMITS.PUZZLE_QUESTIONS) return;
    const idx = this.puzzleIndex;
    this.emit({
      type: "puzzle_question",
      index: idx,
      total: LIMITS.PUZZLE_QUESTIONS,
      text: `Solve: ${this.puzzleAnswers[idx] > 20 ? "a × b" : "a + b"} = ?`,
    });
  }

  private async runFaceCombo() {
    if (this.aborted) return;
    this.emit({ type: "phase_start", phase: "face_combo", durationMs: TIMING.FACE_COMBO_MS });
    for (let ms = 0; ms <= 5000; ms += 200) {
      if (this.aborted) return;
      this.emit({
        type: "capture_progress",
        ms,
        totalMs: 5000,
        sharpness: 55 + Math.random() * 40,
        seq: ms,
      });
      await this.wait(200);
    }
    const subs = SUB_STATUSES.face_combo;
    for (let i = 0; i < subs.length; i++) {
      this.emit({
        type: "phase_sub_status",
        label: subs[i],
        index: i + 1,
        total: subs.length,
      });
      await this.wait(TIMING.SUB_STATUS_MS);
    }
  }

  // [5/15] mock stand-in for the new auto-only Face + ID combo phase.
  private async runIdCombo() {
    if (this.aborted) return;
    this.emit({ type: "phase_start", phase: "id_combo", durationMs: TIMING.ID_COMBO_MS });
    const subs = SUB_STATUSES.id_combo;
    for (let i = 0; i < subs.length; i++) {
      if (this.aborted) return;
      this.emit({ type: "phase_sub_status", label: subs[i], index: i + 1, total: subs.length });
      await this.wait(1200);
    }
  }

  private async runLiveness() {
    if (this.aborted) return;
    this.emit({ type: "phase_start", phase: "liveness", durationMs: TIMING.LIVENESS_MS });
    const prompts: ("blink" | "turn_left" | "turn_right" | "hold_steady")[] = [
      "blink",
      "turn_left",
      "turn_right",
      "hold_steady",
    ];
    for (const p of prompts) {
      if (this.aborted) return;
      this.emit({ type: "movement_prompt", prompt: p });
      await this.wait(4000);
    }
  }

  private async runProcessing() {
    if (this.aborted) return;
    this.emit({ type: "phase_start", phase: "processing", durationMs: TIMING.PROCESSING_MS });
    const subs = SUB_STATUSES.processing;
    for (let i = 0; i < subs.length; i++) {
      this.emit({
        type: "phase_sub_status",
        label: subs[i],
        index: i + 1,
        total: subs.length,
      });
      await this.wait(TIMING.PROCESSING_MS / subs.length);
    }
  }

  private buildResult(): VerificationResult {
    const s = 82 + Math.floor(Math.random() * 15);
    const scores = {
      liveness: 88 + Math.floor(Math.random() * 10),
      faceMatch: 90 + Math.floor(Math.random() * 8),
      documentAuthenticity: 87 + Math.floor(Math.random() * 10),
      dataMatch: 92 + Math.floor(Math.random() * 6),
      overallTrust: s,
    };
    const verdict = s >= 85 ? "approved" : s >= 70 ? "review" : "rejected";
    const reason =
      verdict === "approved"
        ? "All AI agents cleared your ID and face check."
        : verdict === "review"
          ? "Some checks need a human reviewer. We'll email you within 24 hours."
          : "We couldn't confidently verify your identity. Please try again.";
    return {
      id: this.sessionId,
      createdAt: Date.now(),
      verdict,
      reason,
      scores,
      frontChecks: [
        { id: "ocr", label: "OCR text extraction", passed: true, confidence: 0.96 },
        { id: "quality", label: "Image quality (sharpness, glare)", passed: true, confidence: 0.93 },
        { id: "watermark", label: "Watermark verified", passed: true, confidence: 0.91 },
        { id: "tamper", label: "No signs of tampering", passed: true, confidence: 0.94 },
      ],
      backChecks: [
        { id: "ocr", label: "OCR text extraction", passed: true, confidence: 0.94 },
        { id: "quality", label: "Image quality (sharpness, glare)", passed: true, confidence: 0.92 },
        { id: "template", label: "Template & layout match", passed: true, confidence: 0.9 },
        { id: "expiry", label: "Not expired", passed: true, confidence: 0.99 },
      ],
      faceChecks: [
        { id: "match", label: "Face matches ID photo", passed: true, confidence: scores.faceMatch / 100 },
        { id: "liveness", label: "Liveness (blink + head turn)", passed: true, confidence: scores.liveness / 100 },
        { id: "spoof", label: "Anti-spoof (no screen recapture)", passed: true, confidence: 0.95 },
        { id: "id_combo", label: "Face + ID combo (live card + live person)", passed: true, confidence: 0.93 },
        { id: "duplicate", label: "No duplicate face on record", passed: true, confidence: 0.97 },
      ],
      ocrFields: {
        name: "Aarav Sharma",
        dob: "1998-04-12",
        idNumber: "MEN-4821-77X",
        expiry: "2031-04-11",
      },
      captures: {},
    };
  }

  private emit(m: ServerMessage) { this.emitter.emit(m); }
  private wait(ms: number) { return new Promise<void>((r) => setTimeout(r, ms)); }
}

// ---------- WebSocket ----------
class WsVerificationService implements VerificationService {
  private emitter = new Emitter();
  private ws: WebSocket | null = null;
  private sessionId = "";

  connect(sessionId: string) {
    this.sessionId = sessionId;
    const deviceId = getOrCreateDeviceId();
    return new Promise<void>((resolve, reject) => {
      const url = import.meta.env.VITE_VERIFY_WS_URL as string;
      this.emitter.emit({ type: "connection", status: "connecting" });
      const ws = new WebSocket(url);
      this.ws = ws;
      const timer = setTimeout(() => {
        ws.close();
        reject(new Error("WS connect timeout"));
      }, TIMING.WS_CONNECT_TIMEOUT_MS);
      ws.onopen = () => {
        clearTimeout(timer);
        ws.send(JSON.stringify({ type: "session_start", sessionId, deviceId }));
        this.emitter.emit({ type: "connection", status: "live" });
        resolve();
      };
      ws.onerror = () => {
        clearTimeout(timer);
        this.emitter.emit({ type: "connection", status: "error" });
        reject(new Error("WS error"));
      };
      ws.onclose = () => {
        this.emitter.emit({ type: "connection", status: "error" });
      };
      ws.onmessage = (e) => {
        try {
          const msg = JSON.parse(e.data) as ServerMessage;
          this.emitter.emit(msg);
          if (msg.type === "session_end") {
            this.emitter.emit({ type: "connection", status: "done" });
          }
        } catch (err) {
          console.warn("WS parse error", err);
        }
      };
    });
  }

  begin() { this.send({ type: "begin" }); }
  sendCapture(kind: CaptureKind, dataUrl: string, score?: number) {
    this.send({ type: "capture", kind, dataUrl, score });
  }
  submitPuzzleAnswer(index: number, answer: number) {
    this.send({ type: "puzzle_answer", index, answer });
  }
  updateFrameSharpness(value: number) {
    this.send({ type: "frame_sharpness", value });
  }
  abort() {
    this.send({ type: "abort" });
    this.disconnect();
  }
  on(l: Listener) { return this.emitter.on(l); }
  disconnect() {
    if (this.ws) { try { this.ws.close(); } catch {} this.ws = null; }
  }
  private send(m: unknown) {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(m));
    }
  }
}

// ---------- Factory ----------
export async function createVerificationService(sessionId: string): Promise<VerificationService> {
  const url = import.meta.env.VITE_VERIFY_WS_URL as string | undefined;
  if (!url || url.trim().length === 0) {
    throw new Error("VITE_VERIFY_WS_URL not set — check .env.local");
  }
  const svc = new WsVerificationService();
  await svc.connect(sessionId);
  return svc;
}
