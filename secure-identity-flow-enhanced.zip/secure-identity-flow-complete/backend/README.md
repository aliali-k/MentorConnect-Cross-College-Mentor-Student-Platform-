# Backend — run

```
cd backend
cp .env.example .env
npm install
npm run dev
```

Runs on `ws://localhost:8787` by default (matches `.env.example` in the
frontend already).

## Wiring it to the frontend

In the frontend repo, set (or create) `.env.local`:

```
VITE_VERIFY_WS_URL=ws://localhost:8787
```

That's the only frontend change needed — the contract in
`src/verification/types.ts` is implemented exactly by `backend/src/types.ts`.

## Wiring it to the ML service

`ML_SERVICE_URL` in `.env` must point at the running FastAPI service
(default `http://localhost:8000`, see `ml_service/README.md`).

## Optional: Redis

Leave `REDIS_URL` empty to use the built-in JSON-file rate limiter
(`data/device_log.json`). Set `REDIS_URL=redis://localhost:6379` once you've
installed Redis to switch to it — no code changes needed.
