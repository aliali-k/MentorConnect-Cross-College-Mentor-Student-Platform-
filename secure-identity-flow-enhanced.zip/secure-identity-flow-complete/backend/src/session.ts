import type WebSocket from "ws";
import { nanoid } from "nanoid";
import { LIMITS, SUB_STATUSES, TIMING } from "./config.js";
import { PHASE_ORDER, type CaptureKind, type ClientMessage, type Phase, type ServerMessage } from "./types.js";
import { generatePuzzle, type PuzzleQuestion } from "./puzzle.js";
import * as ml from "./mlClient.js";
import { computeScores } from "./scoring.js";
import { saveResult, addToFaceIndex, getFaceIndex } from "./db.js";
import crypto from "node:crypto";

function send(ws: WebSocket, msg: ServerMessage) {
  if (ws.readyState === ws.OPEN) ws.send(JSON.stringify(msg));
}

function sleep(ms: number) {
  return new Promise((res) => setTimeout(res, ms));
}

function phaseDuration(phase: Phase): number {
  switch (phase) {
    case "front_scan": return TIMING.FRONT_SCAN_MS;
    case "tilt": return TIMING.TILT_MS;
    case "back_scan": return TIMING.BACK_SCAN_MS;
    case "puzzle": return TIMING.PUZZLE_MS;
    case "face_combo": return TIMING.FACE_COMBO_MS;
    case "id_combo": return TIMING.ID_COMBO_MS;
    case "liveness": return TIMING.LIVENESS_MS;
    case "processing": return TIMING.PROCESSING_MS;
    default: return 0;
  }
}

// cosine similarity between two embedding vectors (used for duplicate check
// fallback if the ml_service doesn't do it server-side)
function cosineSim(a: number[], b: number[]): number {
  let dot = 0, na = 0, nb = 0;
  for (let i = 0; i < Math.min(a.length, b.length); i++) {
    dot += a[i] * b[i];
    na += a[i] * a[i];
    nb += b[i] * b[i];
  }
  if (na === 0 || nb === 0) return 0;
  return dot / (Math.sqrt(na) * Math.sqrt(nb));
}

// How long we'll wait for the auto-capture / second-tilt-frame counterpart
// of something we already have before giving up and moving on with just the
// one frame we've got. Generous, but bounded — a stalled camera shouldn't
// hang the whole session.
const AUTO_CAPTURE_WAIT_MS = 14000;

export async function runSession(ws: WebSocket, deviceId: string) {
  const sessionId = nanoid();
  let aborted = false;

  const captures: Partial<Record<CaptureKind, string>> = {};
  // [7/15] Per-capture client-reported sharpness/exposure score, so we can
  // pick whichever of a manual/auto pair actually came out best instead of
  // always trusting a fixed one.
  const captureScores: Partial<Record<CaptureKind, number>> = {};
  const frontChecks: import("./types.js").CheckRow[] = [];
  const backChecks: import("./types.js").CheckRow[] = [];
  const faceChecks: import("./types.js").CheckRow[] = [];
  let ocrFields: Record<string, string> = {};
  let faceEmbedding: number[] = [];
  let livenessScore = 0;
  let faceMatchScore = 0;
  let puzzleQuestions: PuzzleQuestion[] = [];
  let puzzleAttemptsLeft = LIMITS.PUZZLE_ATTEMPTS;
  let puzzleIndex = 0;
  let puzzleCorrectCount = 0;
  const livenessFrames: string[] = [];

  const pendingCapture = new Map<CaptureKind, (dataUrl: string) => void>();
  const pendingPuzzleAnswer = new Map<number, (answer: number) => void>();

  function waitForCapture(kind: CaptureKind): Promise<string> {
    return new Promise((resolve) => pendingCapture.set(kind, resolve));
  }
  // [7/15] Like waitForCapture, but gives up after a timeout instead of
  // hanging forever — used for the auto-capture half of a manual/auto pair
  // and for the second tilt frame, both of which are "nice to have, not
  // required to proceed".
  function waitForCaptureWithTimeout(kind: CaptureKind, timeoutMs: number): Promise<string | null> {
    return new Promise((resolve) => {
      let done = false;
      pendingCapture.set(kind, (dataUrl) => {
        if (done) return;
        done = true;
        resolve(dataUrl);
      });
      setTimeout(() => {
        if (done) return;
        done = true;
        pendingCapture.delete(kind);
        resolve(null);
      }, timeoutMs);
    });
  }
  function waitForPuzzleAnswer(index: number): Promise<number> {
    return new Promise((resolve) => pendingPuzzleAnswer.set(index, resolve));
  }

  ws.on("message", (raw: Buffer) => {
    let msg: ClientMessage;
    try {
      msg = JSON.parse(raw.toString());
    } catch {
      return;
    }
    if (msg.type === "abort") {
      aborted = true;
      return;
    }
    if (msg.type === "capture") {
      if (typeof msg.score === "number") captureScores[msg.kind] = msg.score;
      const resolver = pendingCapture.get(msg.kind);
      if (resolver) {
        pendingCapture.delete(msg.kind);
        resolver(msg.dataUrl);
      } else {
        // Arrived before we started waiting (e.g. auto-capture beat our
        // Promise.race setup) — stash it so the wait resolves immediately.
        captures[msg.kind] = msg.dataUrl;
      }
      return;
    }
    if (msg.type === "puzzle_answer") {
      const resolver = pendingPuzzleAnswer.get(msg.index);
      if (resolver) {
        pendingPuzzleAnswer.delete(msg.index);
        resolver(msg.answer);
      }
      return;
    }
    // "session_start", "begin", "frame_sharpness" are read where relevant below.
  });

  async function runSubStatuses(phase: keyof typeof SUB_STATUSES) {
    const labels = SUB_STATUSES[phase];
    for (let i = 0; i < labels.length; i++) {
      if (aborted) return;
      send(ws, { type: "phase_sub_status", label: labels[i], index: i, total: labels.length });
      await sleep(TIMING.SUB_STATUS_MS);
    }
  }

  function toRow(id: string, label: string, passed: boolean, confidence: number, detail?: string): import("./types.js").CheckRow {
    return { id, label, passed, confidence, detail };
  }
  function failCheck(): ml.CheckResult {
    return { passed: false, confidence: 0, detail: "ml_service unavailable" };
  }

  // [7/15] Given a manual/auto pair that's already in `captures`, return
  // whichever one scored better (falls back to whichever exists if only one
  // does, and to manual if neither has a score).
  function bestOf(manualKind: CaptureKind, autoKind: CaptureKind): string | undefined {
    const manual = captures[manualKind];
    const auto = captures[autoKind];
    if (manual && auto) {
      const ms = captureScores[manualKind] ?? -1;
      const as = captureScores[autoKind] ?? -1;
      return as >= ms ? auto : manual;
    }
    return auto ?? manual;
  }

  // [1/15,2/15,3/15,4/15,6/15,7/15,12/15] Manual capture, then its auto
  // counterpart (bounded wait), then run checks against whichever scored
  // best instead of a single fixed frame.
  async function runDocPhase(phase: "front_scan" | "back_scan") {
    send(ws, { type: "phase_start", phase, durationMs: phaseDuration(phase) });
    const manualKind = (phase === "front_scan" ? "front_manual" : "back_manual") as CaptureKind;
    const autoKind = (phase === "front_scan" ? "front_auto" : "back_auto") as CaptureKind;

    const manualDataUrl = captures[manualKind] ?? (await waitForCapture(manualKind));
    if (aborted) return;
    captures[manualKind] = manualDataUrl;
    send(ws, { type: "captured", kind: manualKind, dataUrl: manualDataUrl });

    const autoDataUrl = captures[autoKind] ?? (await waitForCaptureWithTimeout(autoKind, AUTO_CAPTURE_WAIT_MS));
    if (aborted) return;
    if (autoDataUrl) {
      captures[autoKind] = autoDataUrl;
      send(ws, { type: "captured", kind: autoKind, dataUrl: autoDataUrl });
    }

    const bestDataUrl = bestOf(manualKind, autoKind) ?? manualDataUrl;

    const subStatusPromise = runSubStatuses(phase);
    const [ocrRes, screenRes, watermarkRes, elaRes, fontRes, templateRes] = await Promise.all([
      ml.ocr(bestDataUrl).catch(() => ({ fields: {}, confidence: 0, rawText: "" })),
      ml.screenCheck(bestDataUrl).catch(() => failCheck()),
      ml.watermarkCheck(bestDataUrl).catch(() => failCheck()),
      ml.elaCheck(bestDataUrl).catch(() => failCheck()),
      ml.fontCheck(bestDataUrl).catch(() => failCheck()),
      Promise.resolve({ passed: true, confidence: 0.5, detail: "template check skipped" } as ml.CheckResult),
    ]);
    await subStatusPromise;

    ocrFields = { ...ocrFields, ...ocrRes.fields };

    const rows: import("./types.js").CheckRow[] = [
      toRow("ocr_readable", "Text readable", ocrRes.confidence > 0.5, ocrRes.confidence),
      toRow("screen_check", "Not a photo of a screen", screenRes.passed, screenRes.confidence, screenRes.detail),
      toRow("watermark", "Watermark present", watermarkRes.passed, watermarkRes.confidence, watermarkRes.detail),
      toRow("ela", "No tampering (ELA)", elaRes.passed, elaRes.confidence, elaRes.detail),
      toRow("font", "Font consistent with template", fontRes.passed, fontRes.confidence, fontRes.detail),
      toRow("template", "Matches known document template", templateRes.passed, templateRes.confidence, templateRes.detail),
    ];
    (phase === "front_scan" ? frontChecks : backChecks).push(...rows);
  }

  // [8/15,9/15] Real dual-frame tilt capture: wait for both angled frames
  // (bounded), then run a proper two-frame hologram comparison. Falls back
  // to a best-effort single-frame check only if the second angle never
  // arrives (slow camera, user rushed through the phase).
  async function runTiltPhase() {
    send(ws, { type: "phase_start", phase: "tilt", durationMs: phaseDuration("tilt") });
    send(ws, { type: "hint", message: "Tilt the card slowly to show the hologram", level: "info" });

    const frame1 = captures["tilt_frame_1"] ?? (await waitForCaptureWithTimeout("tilt_frame_1", 6000));
    if (frame1) { captures["tilt_frame_1"] = frame1; send(ws, { type: "captured", kind: "tilt_frame_1", dataUrl: frame1 }); }

    const frame2 = captures["tilt_frame_2"] ?? (await waitForCaptureWithTimeout("tilt_frame_2", 6000));
    if (frame2) { captures["tilt_frame_2"] = frame2; send(ws, { type: "captured", kind: "tilt_frame_2", dataUrl: frame2 }); }

    if (frame1 && frame2) {
      const dual = await ml.hologramCheckDual(frame1, frame2).catch(() => failCheck());
      frontChecks.push(toRow("hologram", "Hologram / OVI detected (dual-frame)", dual.passed, dual.confidence, dual.detail));
    } else {
      const single = frame1 ?? frame2 ?? captures["front_auto"] ?? captures["front_manual"];
      if (single) {
        const res = await ml.hologramCheck(single).catch(() => failCheck());
        frontChecks.push(toRow("hologram", "Hologram / OVI detected (single-frame fallback)", res.passed, res.confidence, res.detail));
      }
    }
  }

  async function runPuzzlePhase() {
    send(ws, { type: "phase_start", phase: "puzzle", durationMs: phaseDuration("puzzle") });
    puzzleQuestions = generatePuzzle(LIMITS.PUZZLE_QUESTIONS);
    for (puzzleIndex = 0; puzzleIndex < puzzleQuestions.length; puzzleIndex++) {
      if (aborted) return;
      const q = puzzleQuestions[puzzleIndex];
      send(ws, { type: "puzzle_question", index: puzzleIndex, total: puzzleQuestions.length, text: q.text });
      const answer = await waitForPuzzleAnswer(puzzleIndex);
      const correct = answer === q.answer;
      if (correct) puzzleCorrectCount++;
      else puzzleAttemptsLeft--;
      send(ws, { type: "puzzle_result", correct, attemptsLeft: puzzleAttemptsLeft });
      if (puzzleAttemptsLeft <= 0 && !correct) {
        send(ws, { type: "retry_required", reason: "Bot-check failed" });
        return;
      }
    }
  }

  // [4/15,7/15,12/15] Manual + auto face capture, same best-of selection as
  // the document phases.
  async function runFaceComboPhase() {
    send(ws, { type: "phase_start", phase: "face_combo", durationMs: phaseDuration("face_combo") });
    const subStatusPromise = runSubStatuses("face_combo");

    const manualDataUrl = captures["face_manual"] ?? (await waitForCapture("face_manual"));
    captures["face_manual"] = manualDataUrl;
    send(ws, { type: "captured", kind: "face_manual", dataUrl: manualDataUrl });

    const autoDataUrl = captures["face_auto"] ?? (await waitForCaptureWithTimeout("face_auto", AUTO_CAPTURE_WAIT_MS));
    if (autoDataUrl) {
      captures["face_auto"] = autoDataUrl;
      send(ws, { type: "captured", kind: "face_auto", dataUrl: autoDataUrl });
    }

    const bestSelfie = bestOf("face_manual", "face_auto") ?? manualDataUrl;
    const idPhoto = bestOf("front_manual", "front_auto");
    let matchRes: ml.FaceMatchResult = { match: false, similarity: 0, embedding: [] };
    if (idPhoto) {
      matchRes = await ml.faceMatch(idPhoto, bestSelfie).catch(() => ({ match: false, similarity: 0, embedding: [] }));
    }
    faceMatchScore = matchRes.similarity;
    faceEmbedding = matchRes.embedding;
    faceChecks.push(toRow("face_match", "Face matches ID photo", matchRes.match, matchRes.similarity));
    await subStatusPromise;
  }

  // [5/15,14/15] Brand-new auto-only Face + ID combo phase: waits for the
  // single face_id_combo auto-capture, then runs the anti-spoof sanity
  // check (face present + card present + sane relative distance + not a
  // re-photographed screen).
  async function runIdComboPhase() {
    send(ws, { type: "phase_start", phase: "id_combo", durationMs: phaseDuration("id_combo") });
    const subStatusPromise = runSubStatuses("id_combo");

    const dataUrl = captures["face_id_combo"] ?? (await waitForCapture("face_id_combo"));
    captures["face_id_combo"] = dataUrl;
    send(ws, { type: "captured", kind: "face_id_combo", dataUrl });

    const res = await ml.idComboCheck(dataUrl).catch(
      () => ({ passed: false, confidence: 0, faceDetected: false, cardDetected: false, distanceOk: false, notScreen: false, detail: "ml_service unavailable" } as ml.IdComboResult),
    );
    faceChecks.push(
      toRow(
        "id_combo",
        "Face + ID combo (live card held by live person)",
        res.passed,
        res.confidence,
        res.detail ?? `face=${res.faceDetected} card=${res.cardDetected} distance_ok=${res.distanceOk} not_screen=${res.notScreen}`,
      ),
    );
    livenessFrames.push(dataUrl);
    await subStatusPromise;
  }

  async function runLivenessPhase() {
    send(ws, { type: "phase_start", phase: "liveness", durationMs: phaseDuration("liveness") });
    const prompts: import("./types.js").MovementPrompt[] = ["blink", "turn_left", "turn_right", "hold_steady"];
    for (const prompt of prompts) {
      if (aborted) return;
      send(ws, { type: "movement_prompt", prompt });
      await sleep(TIMING.LIVENESS_MS / prompts.length);
    }
    const bestFace = bestOf("face_manual", "face_auto");
    if (bestFace) livenessFrames.push(bestFace);
    const antiSpoofRes = livenessFrames.length
      ? await ml.antiSpoof(livenessFrames).catch(() => ({ live: false, score: 0 }))
      : { live: false, score: 0 };
    livenessScore = antiSpoofRes.score;
    faceChecks.push(toRow("liveness", "Live person (anti-spoof)", antiSpoofRes.live, antiSpoofRes.score));
  }

  async function runProcessingPhase() {
    send(ws, { type: "phase_start", phase: "processing", durationMs: phaseDuration("processing") });
    const subStatusPromise = runSubStatuses("processing");

    const expiryRes = await ml.expiryCheck(ocrFields).catch(() => ({ expired: false }));
    const dataMatchScore = expiryRes.expired ? 0.2 : 0.9;

    let duplicateFound = false;
    if (faceEmbedding.length > 0) {
      const existing = getFaceIndex();
      for (const entry of existing) {
        if (cosineSim(entry.embedding, faceEmbedding) > 0.9) {
          duplicateFound = true;
          break;
        }
      }
      if (!duplicateFound) addToFaceIndex({ sessionId, embedding: faceEmbedding, createdAt: Date.now() });
    }

    await subStatusPromise;

    const { scores, verdict, reason } = computeScores({
      frontChecks,
      backChecks,
      faceChecks,
      livenessScore,
      faceMatchScore,
      dataMatchScore,
      duplicateFound,
    });

    const result: import("./types.js").VerificationResult = {
      id: sessionId,
      createdAt: Date.now(),
      verdict,
      reason,
      scores,
      frontChecks,
      backChecks,
      faceChecks,
      ocrFields,
      captures,
    };
    saveResult(result);
    send(ws, { type: "session_end", result });
  }

  // ---- main driver ----
  await new Promise<void>((resolve) => {
    const onMessage = (raw: Buffer) => {
      try {
        const msg = JSON.parse(raw.toString()) as ClientMessage;
        if (msg.type === "begin") {
          ws.off("message", onMessage);
          resolve();
        }
      } catch {
        /* ignore */
      }
    };
    ws.on("message", onMessage);
  });

  for (const phase of PHASE_ORDER) {
    if (aborted) break;
    if (phase === "front_scan" || phase === "back_scan") await runDocPhase(phase);
    else if (phase === "tilt") await runTiltPhase();
    else if (phase === "puzzle") await runPuzzlePhase();
    else if (phase === "face_combo") await runFaceComboPhase();
    else if (phase === "id_combo") await runIdComboPhase();
    else if (phase === "liveness") await runLivenessPhase();
    else if (phase === "processing") await runProcessingPhase();
  }
}
