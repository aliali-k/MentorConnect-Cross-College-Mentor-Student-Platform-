import { ENV } from "./config.js";
import type { CheckRow, Scores, Verdict } from "./types.js";

function pct(n: number) {
  return Math.round(Math.max(0, Math.min(1, n)) * 100);
}

function avgConfidence(rows: CheckRow[]): number {
  if (rows.length === 0) return 0;
  return rows.reduce((s, r) => s + (r.passed ? r.confidence : 0), 0) / rows.length;
}

export interface ScoringInput {
  frontChecks: CheckRow[];
  backChecks: CheckRow[];
  faceChecks: CheckRow[];
  livenessScore: number; // 0..1 from anti-spoof
  faceMatchScore: number; // 0..1 from face-match
  dataMatchScore: number; // 0..1, OCR fields cross-check + expiry
  duplicateFound: boolean;
}

export function computeScores(input: ScoringInput): { scores: Scores; verdict: Verdict; reason: string } {
  const documentAuthenticity = pct((avgConfidence(input.frontChecks) + avgConfidence(input.backChecks)) / 2);
  const liveness = pct(input.livenessScore);
  const faceMatch = pct(input.faceMatchScore);
  const dataMatch = pct(input.dataMatchScore);

  const overallTrust = Math.round(
    documentAuthenticity * 0.3 + liveness * 0.25 + faceMatch * 0.3 + dataMatch * 0.15,
  );

  const scores: Scores = { liveness, faceMatch, documentAuthenticity, dataMatch, overallTrust };

  if (input.duplicateFound) {
    return { scores, verdict: "rejected", reason: "Matches an existing verified identity (duplicate)." };
  }
  const anyHardFail = [...input.frontChecks, ...input.backChecks, ...input.faceChecks].some(
    (c) => !c.passed && c.confidence > 0.75,
  );
  if (anyHardFail) {
    return { scores, verdict: "rejected", reason: "One or more checks failed with high confidence." };
  }
  if (overallTrust >= ENV.APPROVE_TRUST_MIN) {
    return { scores, verdict: "approved", reason: "All checks passed within trust thresholds." };
  }
  if (overallTrust <= ENV.REJECT_TRUST_MAX) {
    return { scores, verdict: "rejected", reason: "Overall trust score too low." };
  }
  return { scores, verdict: "review", reason: "Borderline trust score — needs manual review." };
}
