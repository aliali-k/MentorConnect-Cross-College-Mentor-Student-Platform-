// MUST mirror frontend src/verification/types.ts exactly. If you change the
// frontend contract, update this file too — the WS server and the UI must
// never disagree on message shapes.

export type Side = "front" | "back";
export type FacingMode = "environment" | "user";

export type Phase =
  | "welcome"
  | "front_scan"
  | "tilt"
  | "back_scan"
  | "puzzle"
  | "face_combo"
  | "id_combo"
  | "liveness"
  | "processing"
  | "complete";

export const PHASE_ORDER: Phase[] = [
  "front_scan",
  "tilt",
  "back_scan",
  "puzzle",
  "face_combo",
  "id_combo",
  "liveness",
  "processing",
];

// [6/15,12/15] 7 total capture kinds, consistently named manual/auto pairs,
// plus the auto-only face_id_combo and the two real tilt angles.
export type CaptureKind =
  | "front_manual"
  | "front_auto"
  | "back_manual"
  | "back_auto"
  | "face_manual"
  | "face_auto"
  | "face_id_combo"
  | "tilt_frame_1"
  | "tilt_frame_2";

export type MovementPrompt = "blink" | "turn_left" | "turn_right" | "hold_steady";

export type ClientMessage =
  | { type: "session_start"; sessionId: string; deviceId: string }
  | { type: "begin" }
  | { type: "capture"; kind: CaptureKind; dataUrl: string; score?: number }
  | { type: "puzzle_answer"; index: number; answer: number }
  | { type: "frame_sharpness"; value: number }
  | { type: "abort" };

export type ServerMessage =
  | { type: "phase_start"; phase: Phase; durationMs: number }
  | { type: "phase_sub_status"; label: string; index: number; total: number }
  | { type: "hint"; message: string; level?: "info" | "warn" | "error" }
  | { type: "movement_prompt"; prompt: MovementPrompt }
  | { type: "puzzle_question"; index: number; total: number; text: string }
  | { type: "puzzle_result"; correct: boolean; attemptsLeft: number }
  | { type: "capture_progress"; ms: number; totalMs: number; sharpness: number; seq: number }
  | { type: "captured"; kind: CaptureKind; dataUrl: string }
  | { type: "retry_required"; reason: string }
  | { type: "rate_limited"; retryAfterSec: number }
  | { type: "session_end"; result: VerificationResult };

export interface CheckRow {
  id: string;
  label: string;
  passed: boolean;
  confidence: number;
  detail?: string;
}

export interface Scores {
  liveness: number;
  faceMatch: number;
  documentAuthenticity: number;
  dataMatch: number;
  overallTrust: number;
}

export type Verdict = "approved" | "review" | "rejected";

export interface VerificationResult {
  id: string;
  createdAt: number;
  verdict: Verdict;
  reason: string;
  scores: Scores;
  frontChecks: CheckRow[];
  backChecks: CheckRow[];
  faceChecks: CheckRow[];
  ocrFields: Record<string, string>;
  captures: Partial<Record<CaptureKind, string>>;
}
