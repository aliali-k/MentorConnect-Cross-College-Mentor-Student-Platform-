import { WebSocketServer } from "ws";
import { ENV } from "./config.js";
import { checkRateLimit, recordAttempt } from "./rateLimit.js";
import { runSession } from "./session.js";
import type { ClientMessage } from "./types.js";
import crypto from "node:crypto";

const wss = new WebSocketServer({ port: ENV.PORT });
console.log(`[verify-backend] listening on ws://localhost:${ENV.PORT}`);
console.log(`[verify-backend] ML service: ${ENV.ML_SERVICE_URL}`);
console.log(`[verify-backend] Redis: ${ENV.REDIS_URL ? "enabled" : "disabled (in-memory fallback)"}`);

wss.on("connection", (ws, req) => {
  // Device identity: prefer an id the client sends in session_start, else
  // fall back to IP so rate limiting still works before that message arrives.
  const ip = req.socket.remoteAddress ?? "unknown";
  let deviceId = ip;
  let started = false;

  const onFirstMessage = async (raw: Buffer) => {
    let msg: ClientMessage;
    try {
      msg = JSON.parse(raw.toString());
    } catch {
      return;
    }
    if (msg.type !== "session_start" || started) return;
    started = true;
    ws.off("message", onFirstMessage);

    // [15/15] Fixed anti-spam bug: the old code hashed `sessionId`, which the
    // client regenerates with crypto.randomUUID() on every page load — so it
    // never matched a previous attempt and the rate limiter never triggered.
    // The client now sends a separate `deviceId` persisted in localStorage
    // (see verificationService.ts getOrCreateDeviceId); that's what we hash
    // and key the limiter on. IP stays as the fallback for clients that
    // can't persist a deviceId (private browsing, etc).
    deviceId = msg.deviceId
      ? crypto.createHash("sha256").update(msg.deviceId).digest("hex")
      : ip;

    const rl = await checkRateLimit(deviceId);
    if (!rl.allowed) {
      ws.send(JSON.stringify({ type: "rate_limited", retryAfterSec: rl.retryAfterSec }));
      ws.close();
      return;
    }
    await recordAttempt(deviceId);

    try {
      await runSession(ws, deviceId);
    } catch (err) {
      console.error("[verify-backend] session error:", err);
      if (ws.readyState === ws.OPEN) {
        ws.send(JSON.stringify({ type: "hint", message: "Internal error, please retry", level: "error" }));
      }
    } finally {
      ws.close();
    }
  };

  ws.on("message", onFirstMessage);
});
