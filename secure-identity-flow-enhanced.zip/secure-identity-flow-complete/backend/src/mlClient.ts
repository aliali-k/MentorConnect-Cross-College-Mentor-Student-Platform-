import fetch from "node-fetch";
import { ENV } from "./config.js";

const BASE = ENV.ML_SERVICE_URL;

async function post<T>(pathName: string, body: unknown): Promise<T> {
  const res = await fetch(`${BASE}${pathName}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(`ML service ${pathName} failed: ${res.status} ${text}`);
  }
  return (await res.json()) as T;
}

export interface OcrResult {
  fields: Record<string, string>;
  confidence: number;
  rawText: string;
}
export const ocr = (dataUrl: string) => post<OcrResult>("/ocr", { image: dataUrl });

export interface CheckResult {
  passed: boolean;
  confidence: number;
  detail?: string;
}
export const screenCheck = (dataUrl: string) => post<CheckResult>("/screen-check", { image: dataUrl });
export const hologramCheck = (dataUrl: string) => post<CheckResult>("/hologram-check", { image: dataUrl });
// [9/15] Real dual-frame hologram check: compares glint position/color
// between the two angled tilt frames instead of guessing off one frame.
export const hologramCheckDual = (frame1: string, frame2: string) =>
  post<CheckResult>("/hologram-check-dual", { frame1, frame2 });
export const watermarkCheck = (dataUrl: string) => post<CheckResult>("/watermark-check", { image: dataUrl });
export const elaCheck = (dataUrl: string) => post<CheckResult>("/ela-check", { image: dataUrl });
export const templateMatch = (dataUrl: string, docType?: string) =>
  post<CheckResult>("/template-match", { image: dataUrl, doc_type: docType });
export const fontCheck = (dataUrl: string) => post<CheckResult>("/font-check", { image: dataUrl });

export interface FaceMatchResult {
  match: boolean;
  similarity: number; // 0..1
  embedding: number[];
}
export const faceMatch = (idPhotoDataUrl: string, selfieDataUrl: string) =>
  post<FaceMatchResult>("/face-match", { id_photo: idPhotoDataUrl, selfie: selfieDataUrl });

export interface AntiSpoofResult {
  live: boolean;
  score: number; // 0..1, higher = more likely real
}
export const antiSpoof = (frames: string[]) => post<AntiSpoofResult>("/anti-spoof", { frames });

export interface DuplicateResult {
  isDuplicate: boolean;
  matchedSessionId?: string;
  similarity: number;
}
export const duplicateCheck = (embedding: number[], phash: string) =>
  post<DuplicateResult>("/duplicate-check", { embedding, phash });

// [5/15,14/15] Face + ID combo anti-spoof sanity check: confirms a face and
// a card-shaped region are both present in the same frame, at a sane
// relative distance/size, and that the frame itself isn't a re-photographed
// screen (reuses the moiré screen-check logic on the same image).
export interface IdComboResult {
  passed: boolean;
  confidence: number;
  faceDetected: boolean;
  cardDetected: boolean;
  distanceOk: boolean;
  notScreen: boolean;
  detail?: string;
}
export const idComboCheck = (dataUrl: string) => post<IdComboResult>("/id-combo-check", { image: dataUrl });

export interface ExpiryResult {
  expired: boolean;
  expiryDate?: string;
}
export const expiryCheck = (ocrFields: Record<string, string>) =>
  post<ExpiryResult>("/expiry-check", { fields: ocrFields });
