export interface PuzzleQuestion {
  text: string;
  answer: number;
}

// Cheap, server-generated arithmetic questions — the point is only to prove
// there's a human on the other end reacting to server-pushed text in real
// time (a scripted bot replaying captures can't answer these).
export function generatePuzzle(count: number): PuzzleQuestion[] {
  const qs: PuzzleQuestion[] = [];
  for (let i = 0; i < count; i++) {
    const a = 2 + Math.floor(Math.random() * 8);
    const b = 2 + Math.floor(Math.random() * 8);
    const op = Math.random() > 0.5 ? "+" : "-";
    const answer = op === "+" ? a + b : a - b;
    qs.push({ text: `What is ${a} ${op} ${b}?`, answer });
  }
  return qs;
}
