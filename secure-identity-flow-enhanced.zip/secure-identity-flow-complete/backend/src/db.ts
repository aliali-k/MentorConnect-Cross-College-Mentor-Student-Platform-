import fs from "node:fs";
import path from "node:path";
import { ENV } from "./config.js";
import type { VerificationResult } from "./types.js";

// Simple JSON-file DB. Good enough for dev/small volume; swap for Postgres/Mongo
// later without touching session.ts — only the functions below need to change.

const DATA_DIR = path.resolve(ENV.DATA_DIR);
const RESULTS_FILE = path.join(DATA_DIR, "results.json");
const REVIEW_QUEUE_FILE = path.join(DATA_DIR, "review_queue.json");
const DEVICE_LOG_FILE = path.join(DATA_DIR, "device_log.json");
const FACE_INDEX_FILE = path.join(DATA_DIR, "face_index.json"); // for duplicate-identity checks

function ensureFile(file: string, initial: unknown) {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(file)) fs.writeFileSync(file, JSON.stringify(initial, null, 2));
}

function readJson<T>(file: string, initial: T): T {
  ensureFile(file, initial);
  try {
    return JSON.parse(fs.readFileSync(file, "utf-8")) as T;
  } catch {
    return initial;
  }
}

function writeJson(file: string, data: unknown) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

export function saveResult(result: VerificationResult) {
  const all = readJson<VerificationResult[]>(RESULTS_FILE, []);
  all.push(result);
  writeJson(RESULTS_FILE, all);

  if (result.verdict === "review") {
    const queue = readJson<VerificationResult[]>(REVIEW_QUEUE_FILE, []);
    queue.push(result);
    writeJson(REVIEW_QUEUE_FILE, queue);
  }
}

export function getResult(id: string): VerificationResult | undefined {
  const all = readJson<VerificationResult[]>(RESULTS_FILE, []);
  return all.find((r) => r.id === id);
}

export function getReviewQueue(): VerificationResult[] {
  return readJson<VerificationResult[]>(REVIEW_QUEUE_FILE, []);
}

// ---- device/session throttling log (used by rateLimit.ts fallback) ----
interface DeviceLogEntry {
  deviceId: string;
  timestamps: number[]; // epoch ms of past attempts
}

export function getDeviceLog(deviceId: string): number[] {
  const log = readJson<DeviceLogEntry[]>(DEVICE_LOG_FILE, []);
  return log.find((e) => e.deviceId === deviceId)?.timestamps ?? [];
}

export function pushDeviceAttempt(deviceId: string) {
  const log = readJson<DeviceLogEntry[]>(DEVICE_LOG_FILE, []);
  const entry = log.find((e) => e.deviceId === deviceId);
  const now = Date.now();
  if (entry) entry.timestamps.push(now);
  else log.push({ deviceId, timestamps: [now] });
  writeJson(DEVICE_LOG_FILE, log);
}

// ---- face embedding index (duplicate-identity detection across sessions) ----
export interface FaceIndexEntry {
  sessionId: string;
  embedding: number[];
  createdAt: number;
}

export function getFaceIndex(): FaceIndexEntry[] {
  return readJson<FaceIndexEntry[]>(FACE_INDEX_FILE, []);
}

export function addToFaceIndex(entry: FaceIndexEntry) {
  const idx = readJson<FaceIndexEntry[]>(FACE_INDEX_FILE, []);
  idx.push(entry);
  writeJson(FACE_INDEX_FILE, idx);
}
