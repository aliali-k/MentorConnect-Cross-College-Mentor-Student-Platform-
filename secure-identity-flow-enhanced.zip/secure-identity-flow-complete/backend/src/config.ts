import "dotenv/config";

// Must match frontend src/verification/config.ts TIMING exactly, or the
// client-side progress bars and the server's own timers will disagree.
export const TIMING = {
  FRONT_SCAN_MS: 32000,
  TILT_MS: 38000,
  BACK_SCAN_MS: 32000,
  PUZZLE_MS: 42000,
  FACE_COMBO_MS: 30000,
  ID_COMBO_MS: 26000,
  LIVENESS_MS: 28000,
  PROCESSING_MS: 8000,
  SESSION_TOTAL_CAP_MS: 6 * 60 * 1000,
  SUB_STATUS_MS: 3500,
} as const;

export const LIMITS = {
  PUZZLE_ATTEMPTS: 3,
  PUZZLE_QUESTIONS: 3,
  CAPTURE_RETRIES: 2,
} as const;

export const SUB_STATUSES = {
  front_scan: ["Reading text", "Checking image quality", "Verifying watermark", "Checking for edits"],
  back_scan: ["Reading text", "Checking image quality", "Verifying watermark", "Checking for edits"],
  face_combo: ["Comparing with ID photo", "Checking liveness"],
  id_combo: ["Detecting face and card", "Checking distance and framing", "Confirming it's not a screen or printout"],
  processing: [
    "Verifying document authenticity",
    "Cross-checking data fields",
    "Scanning for duplicate identities",
    "Finalizing your trust score",
  ],
} as const;

export const ENV = {
  PORT: Number(process.env.PORT ?? 8787),
  ML_SERVICE_URL: process.env.ML_SERVICE_URL ?? "http://localhost:8000",
  REDIS_URL: process.env.REDIS_URL ?? "", // empty = fall back to in-memory limiter
  DATA_DIR: process.env.DATA_DIR ?? "./data",
  MAX_SESSIONS_PER_DEVICE_PER_DAY: Number(process.env.MAX_SESSIONS_PER_DEVICE_PER_DAY ?? 5),
  MIN_SECONDS_BETWEEN_ATTEMPTS: Number(process.env.MIN_SECONDS_BETWEEN_ATTEMPTS ?? 30),
  // Thresholds the scoring engine uses to decide the verdict.
  APPROVE_TRUST_MIN: Number(process.env.APPROVE_TRUST_MIN ?? 80),
  REJECT_TRUST_MAX: Number(process.env.REJECT_TRUST_MAX ?? 40),
};
