import Redis from "ioredis";
import { ENV } from "./config.js";
import { getDeviceLog, pushDeviceAttempt } from "./db.js";

let redis: Redis | null = null;
if (ENV.REDIS_URL) {
  redis = new Redis(ENV.REDIS_URL);
  redis.on("error", (err) => console.error("[redis] connection error:", err.message));
}

export interface RateLimitResult {
  allowed: boolean;
  retryAfterSec: number;
}

// Two rules, mirroring what the frontend copy already promises the user:
// 1. cooldown between attempts from the same device
// 2. a daily cap on attempts per device
export async function checkRateLimit(deviceId: string): Promise<RateLimitResult> {
  if (redis) return checkRateLimitRedis(deviceId);
  return checkRateLimitFallback(deviceId);
}

export async function recordAttempt(deviceId: string): Promise<void> {
  if (redis) {
    const now = Date.now();
    await redis.set(`verify:last:${deviceId}`, String(now), "EX", 86400);
    await redis.incr(`verify:count:${deviceId}:${dayKey()}`);
    await redis.expire(`verify:count:${deviceId}:${dayKey()}`, 90000);
    return;
  }
  pushDeviceAttempt(deviceId);
}

function dayKey() {
  return new Date().toISOString().slice(0, 10);
}

async function checkRateLimitRedis(deviceId: string): Promise<RateLimitResult> {
  const last = await redis!.get(`verify:last:${deviceId}`);
  if (last) {
    const elapsedSec = (Date.now() - Number(last)) / 1000;
    if (elapsedSec < ENV.MIN_SECONDS_BETWEEN_ATTEMPTS) {
      return { allowed: false, retryAfterSec: Math.ceil(ENV.MIN_SECONDS_BETWEEN_ATTEMPTS - elapsedSec) };
    }
  }
  const count = Number((await redis!.get(`verify:count:${deviceId}:${dayKey()}`)) ?? 0);
  if (count >= ENV.MAX_SESSIONS_PER_DEVICE_PER_DAY) {
    return { allowed: false, retryAfterSec: 60 * 60 };
  }
  return { allowed: true, retryAfterSec: 0 };
}

function checkRateLimitFallback(deviceId: string): RateLimitResult {
  const attempts = getDeviceLog(deviceId);
  const now = Date.now();
  const last = attempts[attempts.length - 1];
  if (last) {
    const elapsedSec = (now - last) / 1000;
    if (elapsedSec < ENV.MIN_SECONDS_BETWEEN_ATTEMPTS) {
      return { allowed: false, retryAfterSec: Math.ceil(ENV.MIN_SECONDS_BETWEEN_ATTEMPTS - elapsedSec) };
    }
  }
  const todayCount = attempts.filter((t) => now - t < 86400000).length;
  if (todayCount >= ENV.MAX_SESSIONS_PER_DEVICE_PER_DAY) {
    return { allowed: false, retryAfterSec: 3600 };
  }
  return { allowed: true, retryAfterSec: 0 };
}
