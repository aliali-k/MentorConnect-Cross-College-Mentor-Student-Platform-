# Setup order (ask me about each one by one)

1. Extract this zip next to your existing frontend repo (`secure-identity-flow-...`).
2. `cd backend && cp .env.example .env && npm install && npm run dev` → real WS server on :8787.
3. In the frontend, set `.env.local`: `VITE_VERIFY_WS_URL=ws://localhost:8787`.
4. `cd ml_service && pip install -r requirements.txt` (top half only) → `uvicorn main:app --reload --port 8000`.
   At this point: screen-check, ELA, watermark, hologram, font-check, duplicate-hash, and expiry-check are ALL real and working. OCR/face-match/liveness report "not available yet".
5. Install PaddleOCR-VL-1.6 (`pip install paddlepaddle paddleocr`) → OCR goes live.
6. Install InsightFace (`pip install insightface onnxruntime`) → face-match goes live.
7. Clone Silent-Face-Anti-Spoofing into `ml_service/vendor/` → liveness goes live.
8. (Optional) Install Qwen2.5-VL-7B for OCR cross-check.
9. (Optional) Install Redis, set `REDIS_URL` in backend `.env`.
10. Drop reference ID template images into `ml_service/templates/<doc_type>/reference.jpg` → template-match goes live.

Full detail for each step is in backend/README.md and ml_service/README.md.
