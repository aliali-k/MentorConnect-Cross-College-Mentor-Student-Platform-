import base64
import re
import numpy as np
import cv2
from PIL import Image
from io import BytesIO

DATA_URL_RE = re.compile(r"^data:image/\w+;base64,")


def data_url_to_bytes(data_url: str) -> bytes:
    stripped = DATA_URL_RE.sub("", data_url)
    return base64.b64decode(stripped)


def data_url_to_cv2(data_url: str) -> np.ndarray:
    """Returns a BGR OpenCV image."""
    raw = data_url_to_bytes(data_url)
    arr = np.frombuffer(raw, dtype=np.uint8)
    img = cv2.imdecode(arr, cv2.IMREAD_COLOR)
    if img is None:
        raise ValueError("Could not decode image")
    return img


def data_url_to_pil(data_url: str) -> Image.Image:
    raw = data_url_to_bytes(data_url)
    return Image.open(BytesIO(raw)).convert("RGB")
