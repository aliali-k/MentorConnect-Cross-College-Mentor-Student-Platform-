"""
Real integration code for PaddleOCR-VL-1.6 (primary OCR) with an optional
Qwen2.5-VL-7B cross-check pass. Both are lazy-loaded on first request so the
service still boots and the rest of the pipeline keeps working even before
you've downloaded the weights — see ml_service/README.md for exact download
steps. Until then, calls here return confidence=0 with an explanatory
`rawText`, which the backend already treats as "OCR failed, keep going with
the other checks" rather than crashing the session.
"""
import re
import cv2
import numpy as np
from imgutils import data_url_to_pil

_paddle_ocr = None
_qwen_model = None
_qwen_processor = None

MODELS_READY = {"paddleocr": False, "qwen": False}

# Regex-based field extraction from raw OCR text. Tune per document type —
# this is deliberately generic (name/DOB/ID-number/expiry patterns) since
# every country's ID layout differs.
FIELD_PATTERNS = {
    "date_of_birth": re.compile(r"\b(\d{1,2}[/\-.]\d{1,2}[/\-.]\d{2,4})\b"),
    "id_number": re.compile(r"\b([A-Z0-9]{6,15})\b"),
}


def _load_paddle():
    global _paddle_ocr
    if _paddle_ocr is not None:
        return _paddle_ocr
    try:
        from paddleocr import PaddleOCR
        # lang="en" — change per your target documents' language(s)
        _paddle_ocr = PaddleOCR(use_angle_cls=True, lang="en")
        MODELS_READY["paddleocr"] = True
    except Exception as e:  # noqa: BLE001
        _paddle_ocr = False
        print(f"[ocr] PaddleOCR not available yet: {e}")
    return _paddle_ocr


def _load_qwen():
    global _qwen_model, _qwen_processor
    if _qwen_model is not None:
        return _qwen_model, _qwen_processor
    try:
        import torch
        from transformers import Qwen2VLForConditionalGeneration, AutoProcessor
        _qwen_model = Qwen2VLForConditionalGeneration.from_pretrained(
            "Qwen/Qwen2.5-VL-7B-Instruct", torch_dtype=torch.float16, device_map="auto"
        )
        _qwen_processor = AutoProcessor.from_pretrained("Qwen/Qwen2.5-VL-7B-Instruct")
        MODELS_READY["qwen"] = True
    except Exception as e:  # noqa: BLE001
        _qwen_model, _qwen_processor = False, False
        print(f"[ocr] Qwen2.5-VL not available yet: {e}")
    return _qwen_model, _qwen_processor


def _preprocess_for_ocr(rgb: "np.ndarray") -> "np.ndarray":
    """
    [11/15] CLAHE contrast + deskew before OCR. This only helps once the
    capture bug (#1) is fixed and OCR actually receives a full-resolution
    frame — cleaning up a blurry downsampled crop doesn't recover detail
    that was never captured.
      - CLAHE (contrast-limited adaptive histogram equalization) evens out
        harsh lighting/glare across the card without blowing out bright
        regions the way plain global equalization would.
      - Deskew: estimates the dominant text-line angle via the minimum-area
        bounding box of thresholded ink pixels and rotates it level, since
        even a few degrees of skew measurably hurts OCR accuracy.
    """
    bgr = cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)
    gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)

    clahe = cv2.createCLAHE(clipLimit=2.5, tileGridSize=(8, 8))
    enhanced_gray = clahe.apply(gray)
    lab = cv2.cvtColor(bgr, cv2.COLOR_BGR2LAB)
    l, a, b = cv2.split(lab)
    l = clahe.apply(l)
    enhanced_bgr = cv2.cvtColor(cv2.merge([l, a, b]), cv2.COLOR_LAB2BGR)

    # Deskew based on ink pixel distribution.
    _, thresh = cv2.threshold(enhanced_gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
    coords = cv2.findNonZero(thresh)
    angle = 0.0
    if coords is not None and len(coords) > 50:
        rect = cv2.minAreaRect(coords)
        angle = rect[-1]
        if angle < -45:
            angle = 90 + angle
        # Only correct small skews — large angles usually mean the minAreaRect
        # locked onto something other than the text block (e.g. a photo/logo).
        if abs(angle) > 12:
            angle = 0.0

    if abs(angle) > 0.3:
        h, w = enhanced_bgr.shape[:2]
        m = cv2.getRotationMatrix2D((w / 2, h / 2), angle, 1.0)
        enhanced_bgr = cv2.warpAffine(enhanced_bgr, m, (w, h), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REPLICATE)

    return cv2.cvtColor(enhanced_bgr, cv2.COLOR_BGR2RGB)


def run_ocr(data_url: str) -> tuple[dict[str, str], float, str]:
    pil_img = data_url_to_pil(data_url)
    paddle = _load_paddle()

    if not paddle:
        return {}, 0.0, "[OCR unavailable — PaddleOCR-VL-1.6 not installed, see ml_service/README.md]"

    preprocessed = _preprocess_for_ocr(np.array(pil_img))
    result = paddle.ocr(preprocessed, cls=True)
    lines = []
    confidences = []
    for block in result or []:
        for line in block or []:
            text, conf = line[1][0], line[1][1]
            lines.append(text)
            confidences.append(conf)
    raw_text = "\n".join(lines)
    avg_conf = float(sum(confidences) / len(confidences)) if confidences else 0.0

    fields: dict[str, str] = {}
    for name, pattern in FIELD_PATTERNS.items():
        m = pattern.search(raw_text)
        if m:
            fields[name] = m.group(1)

    # Optional cross-check: ask Qwen2.5-VL to independently read the same
    # image and confirm/deny PaddleOCR's field extraction. Skipped if the
    # model isn't loaded — PaddleOCR's own result still stands.
    qwen_model, qwen_processor = _load_qwen()
    if qwen_model and fields:
        try:
            cross_checked = _qwen_cross_check(pil_img, fields, qwen_model, qwen_processor)
            fields.update(cross_checked)
        except Exception as e:  # noqa: BLE001
            print(f"[ocr] Qwen cross-check failed, keeping PaddleOCR result: {e}")

    return fields, avg_conf, raw_text


def _qwen_cross_check(pil_img, fields, model, processor) -> dict[str, str]:
    """Ask Qwen2.5-VL to re-read the fields PaddleOCR extracted; only used to
    flag disagreement (appends a '_qwen' shadow field) rather than silently
    overwrite — the caller can decide how strict to be."""
    prompt = (
        "Read this ID document and return the following fields as plain "
        f"text, one per line, in the form key: value. Fields: {', '.join(fields.keys())}"
    )
    inputs = processor(text=prompt, images=pil_img, return_tensors="pt").to(model.device)
    output = model.generate(**inputs, max_new_tokens=200)
    decoded = processor.batch_decode(output, skip_special_tokens=True)[0]

    shadow: dict[str, str] = {}
    for line in decoded.splitlines():
        if ":" in line:
            k, v = line.split(":", 1)
            k = k.strip().lower().replace(" ", "_")
            if k in fields:
                shadow[f"{k}_qwen_check"] = v.strip()
    return shadow
