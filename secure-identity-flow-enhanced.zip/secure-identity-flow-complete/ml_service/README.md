# ML service — model setup

Everything in `document_checks.py`, `duplicate.py`, and `expiry.py` runs with
just `pip install -r requirements.txt` (the top, uncommented half of that
file). No downloads needed for those.

The four heavy models are lazy-loaded — the service boots and those checks
just report "not available yet" until you install each one. Do them one at a
time, in this order, and restart the service after each:

1. **PaddleOCR-VL-1.6** — `pip install paddlepaddle paddleocr` (downloads
   ~150MB detection+recognition weights automatically on first call to
   `ocr.py`'s `_load_paddle()`).
2. **InsightFace (buffalo_l)** — `pip install insightface onnxruntime`
   (downloads ~300MB on first call to `face.py`'s `_load_insightface()`).
3. **Silent-Face-Anti-Spoofing** — not on PyPI, clone the repo into
   `ml_service/vendor/Silent_Face_Anti_Spoofing/` (path `face.py` already
   imports from).
4. **Qwen2.5-VL-7B-Instruct** — `pip install torch transformers` then it
   pulls from Hugging Face on first call; needs a GPU with ~16GB VRAM for
   fp16, or drop to a smaller Qwen2.5-VL variant. Optional — OCR still works
   with just PaddleOCR if you skip this.

Also add reference template images for `template_match()` in
`templates/<doc_type>/reference.jpg` — a clean, flat scan of each ID type
you accept, front side.

Run with: `uvicorn main:app --reload --port 8000`
