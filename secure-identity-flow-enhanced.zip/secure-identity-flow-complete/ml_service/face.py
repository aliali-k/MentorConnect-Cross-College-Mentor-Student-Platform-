"""
Real integration code for InsightFace (detection + embedding + matching) and
Silent-Face-Anti-Spoofing (liveness/anti-spoof). Both lazy-load on first use
so the service still runs the OpenCV-only checks even before you've
downloaded weights — see ml_service/README.md.
"""
import os
import sys
import numpy as np
from imgutils import data_url_to_cv2

_face_app = None
_spoof_model = None
_image_cropper = None

MODELS_READY = {"insightface": False, "anti_spoof": False}

VENDOR_DIR = os.path.join(os.path.dirname(__file__), "vendor", "Silent_Face_Anti_Spoofing")
ANTI_SPOOF_MODEL_DIR = os.path.join(VENDOR_DIR, "resources", "anti_spoof_models")


def _load_insightface():
    global _face_app
    if _face_app is not None:
        return _face_app
    try:
        import insightface
        from insightface.app import FaceAnalysis
        _face_app = FaceAnalysis(name="buffalo_l", providers=["CPUExecutionProvider"])
        _face_app.prepare(ctx_id=0, det_size=(640, 640))
        MODELS_READY["insightface"] = True
    except Exception as e:  # noqa: BLE001
        _face_app = False
        print(f"[face] InsightFace not available yet: {e}")
    return _face_app


def _load_anti_spoof():
    global _spoof_model, _image_cropper
    if _spoof_model is not None:
        return _spoof_model
    try:
        if VENDOR_DIR not in sys.path:
            sys.path.insert(0, VENDOR_DIR)
        from src.anti_spoof_predict import AntiSpoofPredict
        from src.generate_patches import CropImage
        _spoof_model = AntiSpoofPredict(device_id=0)
        _image_cropper = CropImage()
        MODELS_READY["anti_spoof"] = True
    except Exception as e:  # noqa: BLE001
        _spoof_model = False
        print(f"[face] Silent-Face-Anti-Spoofing not available yet: {e}")
    return _spoof_model


def embed_face(data_url: str) -> np.ndarray | None:
    app = _load_insightface()
    if not app:
        return None
    img = data_url_to_cv2(data_url)
    faces = app.get(img)
    if not faces:
        return None
    face = max(faces, key=lambda f: (f.bbox[2] - f.bbox[0]) * (f.bbox[3] - f.bbox[1]))
    return face.normed_embedding


def face_match(id_photo_data_url: str, selfie_data_url: str) -> tuple[bool, float, list[float]]:
    emb_id = embed_face(id_photo_data_url)
    emb_selfie = embed_face(selfie_data_url)
    if emb_id is None or emb_selfie is None:
        return False, 0.0, []
    similarity = float(np.dot(emb_id, emb_selfie))
    match = similarity > 0.28
    confidence = max(0.0, min(1.0, (similarity + 1) / 2))
    return match, confidence, emb_selfie.tolist()


def anti_spoof(frame_data_urls: list[str]) -> tuple[bool, float]:
    model = _load_anti_spoof()
    if not model or not frame_data_urls:
        return False, 0.0

    from src.utility import parse_model_name  # noqa: E402

    scores = []
    for data_url in frame_data_urls:
        img = data_url_to_cv2(data_url)
        bbox = model.get_bbox(img)
        prediction = np.zeros((1, 3))
        for model_name in os.listdir(ANTI_SPOOF_MODEL_DIR):
            h_input, w_input, model_type, scale = parse_model_name(model_name)
            param = {
                "org_img": img,
                "bbox": bbox,
                "scale": scale,
                "out_w": w_input,
                "out_h": h_input,
                "crop": True,
            }
            if scale is None:
                param["crop"] = False
            cropped = _image_cropper.crop(**param)
            prediction += model.predict(cropped, os.path.join(ANTI_SPOOF_MODEL_DIR, model_name))
        label = int(np.argmax(prediction))
        live_score = float(prediction[0][1] / 2)
        scores.append(live_score if label == 1 else 1 - live_score)

    avg_score = sum(scores) / len(scores)
    return avg_score > 0.5, avg_score