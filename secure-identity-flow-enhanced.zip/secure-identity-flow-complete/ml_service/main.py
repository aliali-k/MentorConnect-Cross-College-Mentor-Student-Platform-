from fastapi import FastAPI
from schemas import (
    ImageIn, TemplateMatchIn, CheckOut, OcrOut,
    FaceMatchIn, FaceMatchOut, AntiSpoofIn, AntiSpoofOut,
    DuplicateCheckIn, DuplicateCheckOut, ExpiryCheckIn, ExpiryCheckOut,
    DualFrameIn, IdComboOut,
)
import document_checks as dc
import ocr as ocr_mod
import face as face_mod
import duplicate as dup_mod
import expiry as expiry_mod

app = FastAPI(title="Identity Verification ML Service")


@app.get("/health")
def health():
    return {
        "status": "ok",
        "models": {**ocr_mod.MODELS_READY, **face_mod.MODELS_READY},
    }


@app.post("/ocr", response_model=OcrOut)
def ocr_endpoint(body: ImageIn):
    fields, confidence, raw_text = ocr_mod.run_ocr(body.image)
    return OcrOut(fields=fields, confidence=confidence, rawText=raw_text)


@app.post("/screen-check", response_model=CheckOut)
def screen_check_endpoint(body: ImageIn):
    return dc.screen_check(body.image)


@app.post("/hologram-check", response_model=CheckOut)
def hologram_check_endpoint(body: ImageIn):
    return dc.hologram_check(body.image)


@app.post("/watermark-check", response_model=CheckOut)
def watermark_check_endpoint(body: ImageIn):
    return dc.watermark_check(body.image)


@app.post("/hologram-check-dual", response_model=CheckOut)
def hologram_check_dual_endpoint(body: DualFrameIn):
    return dc.hologram_check_dual(body.frame1, body.frame2)


@app.post("/id-combo-check", response_model=IdComboOut)
def id_combo_check_endpoint(body: ImageIn):
    return dc.id_combo_check(body.image)


@app.post("/ela-check", response_model=CheckOut)
def ela_check_endpoint(body: ImageIn):
    return dc.ela_check(body.image)


@app.post("/template-match", response_model=CheckOut)
def template_match_endpoint(body: TemplateMatchIn):
    return dc.template_match(body.image, body.doc_type)


@app.post("/font-check", response_model=CheckOut)
def font_check_endpoint(body: ImageIn):
    return dc.font_check(body.image)


@app.post("/face-match", response_model=FaceMatchOut)
def face_match_endpoint(body: FaceMatchIn):
    match, similarity, embedding = face_mod.face_match(body.id_photo, body.selfie)
    return FaceMatchOut(match=match, similarity=similarity, embedding=embedding)


@app.post("/anti-spoof", response_model=AntiSpoofOut)
def anti_spoof_endpoint(body: AntiSpoofIn):
    live, score = face_mod.anti_spoof(body.frames)
    return AntiSpoofOut(live=live, score=score)


@app.post("/duplicate-check", response_model=DuplicateCheckOut)
def duplicate_check_endpoint(body: DuplicateCheckIn):
    # Face-embedding half of duplicate detection is handled in the Node
    # backend (it keeps the cross-session embedding index). This endpoint is
    # kept for parity with the contract / future use if you want the phash
    # index to live here instead — currently just echoes "not duplicate".
    return DuplicateCheckOut(isDuplicate=False, similarity=0.0)


@app.post("/expiry-check", response_model=ExpiryCheckOut)
def expiry_check_endpoint(body: ExpiryCheckIn):
    expired, expiry_date = expiry_mod.check_expiry(body.fields)
    return ExpiryCheckOut(expired=expired, expiryDate=expiry_date)
