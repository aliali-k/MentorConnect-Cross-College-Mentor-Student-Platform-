"""
Real, working OpenCV/NumPy/Pillow implementations. No model downloads needed.
These are classic forensic heuristics — good enough to ship and tune, but you
should calibrate the thresholds against a batch of your own real vs fake
sample IDs before trusting them in production.
"""
import io
import cv2
import numpy as np
from PIL import Image
from imgutils import data_url_to_cv2, data_url_to_pil
from schemas import CheckOut

TEMPLATES_DIR = "templates"  # put reference ID template images here, see README


def screen_check(data_url: str) -> CheckOut:
    """
    Detect "photo of a screen" recaptures via moire pattern energy in the
    frequency domain. Screens produce a periodic pixel-grid pattern that
    shows up as strong high-frequency peaks off the DC term.
    """
    img = data_url_to_cv2(data_url)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    gray = cv2.resize(gray, (512, 512))
    f = np.fft.fft2(gray)
    fshift = np.fft.fftshift(f)
    magnitude = np.log(np.abs(fshift) + 1)

    h, w = magnitude.shape
    cy, cx = h // 2, w // 2
    # zero out the low-frequency DC blob, then look at energy in the ring
    # around it — moire/screen-grid patterns show up as bright rings/spikes
    ring_mask = np.ones_like(magnitude)
    cv2.circle(ring_mask, (cx, cy), 20, 0, -1)
    ring_energy = float(np.mean(magnitude * ring_mask))
    baseline = float(np.mean(magnitude))
    ratio = ring_energy / (baseline + 1e-6)

    # heuristic threshold — tune against real samples
    is_screen = ratio > 1.35
    confidence = min(1.0, abs(ratio - 1.0))
    return CheckOut(passed=not is_screen, confidence=round(confidence, 3),
                     detail=f"moire_ratio={ratio:.3f}")


def ela_check(data_url: str) -> CheckOut:
    """
    Error Level Analysis: recompress the image at a known JPEG quality and
    diff against the original. Regions that were edited/pasted-in tend to
    have a different compression error signature than the rest of the image.
    """
    pil_img = data_url_to_pil(data_url)
    buf = io.BytesIO()
    pil_img.save(buf, "JPEG", quality=90)
    buf.seek(0)
    recompressed = Image.open(buf)

    orig = np.array(pil_img).astype(np.int16)
    recomp = np.array(recompressed).astype(np.int16)
    diff = np.abs(orig - recomp)

    mean_err = float(np.mean(diff))
    std_err = float(np.std(diff))
    # localized tampering shows up as isolated high-error blobs far above the
    # image's own mean error level
    high_error_mask = diff.mean(axis=2) > (mean_err + 3 * std_err)
    suspicious_fraction = float(np.mean(high_error_mask))

    passed = suspicious_fraction < 0.02  # <2% of pixels flagged
    confidence = min(1.0, suspicious_fraction * 20)
    return CheckOut(passed=passed, confidence=round(1 - confidence if passed else confidence, 3),
                     detail=f"suspicious_fraction={suspicious_fraction:.4f}")


def watermark_check(data_url: str) -> CheckOut:
    """
    [10/15] Stronger watermark check: combines the original texture-variance
    heuristic (mid-tone local contrast, typical of ghost/watermark security
    print) with an independent FFT mid-frequency-band signal, and requires
    BOTH to agree before passing. A flat photocopy/screenshot tends to fail
    one or both; requiring agreement cuts down on single-heuristic false
    positives. Still not a substitute for a real per-document-type watermark
    template match — see README for how to add reference watermark masks
    per document type under templates/<doc_type>/watermark_mask.png.
    """
    img = data_url_to_cv2(data_url)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    # Signal 1: local variance in mid-tone regions.
    mid_tone_mask = (gray > 80) & (gray < 180)
    if mid_tone_mask.sum() < 500:
        return CheckOut(passed=False, confidence=0.3, detail="not enough midtone area to evaluate")
    local_std = cv2.Laplacian(gray, cv2.CV_64F).var()
    texture_passed = local_std > 15
    texture_confidence = min(1.0, local_std / 60)

    # Signal 2: mid-frequency energy in the FFT spectrum. Genuine watermark
    # security print adds a faint, fine repeating texture that shows up as a
    # ring of energy between the low-frequency document content and the
    # high-frequency noise floor — flat prints/screenshots don't have it.
    resized = cv2.resize(gray, (512, 512))
    f = np.fft.fft2(resized)
    fshift = np.fft.fftshift(f)
    magnitude = np.log(np.abs(fshift) + 1)
    h, w = magnitude.shape
    cy, cx = h // 2, w // 2
    mid_band = np.zeros_like(magnitude)
    cv2.circle(mid_band, (cx, cy), 90, 1, -1)
    cv2.circle(mid_band, (cx, cy), 30, 0, -1)
    mid_band_energy = float(np.mean(magnitude[mid_band > 0]))
    baseline = float(np.mean(magnitude))
    fft_ratio = mid_band_energy / (baseline + 1e-6)
    fft_passed = fft_ratio > 1.02
    fft_confidence = min(1.0, max(0.0, (fft_ratio - 1.0) * 8))

    passed = texture_passed and fft_passed
    confidence = round((texture_confidence + fft_confidence) / 2, 3)
    return CheckOut(
        passed=passed,
        confidence=confidence,
        detail=f"texture_var={local_std:.2f} fft_mid_band_ratio={fft_ratio:.3f}",
    )


def hologram_check(data_url: str) -> CheckOut:
    """
    Holograms/OVI (optically variable ink) shift color/brightness depending
    on viewing angle. A single still frame can't fully verify this — real
    hologram verification needs 2+ frames from the 'tilt' phase compared for
    localized color-channel shifts. This computes a proxy: specular
    highlight + high-saturation-patch density, which correlates with foil
    holograms even in a single frame.
    """
    img = data_url_to_cv2(data_url)
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    sat = hsv[:, :, 1]
    val = hsv[:, :, 2]
    # bright + saturated small patches = plausible foil/hologram glints
    glint_mask = (val > 220) & (sat > 60)
    glint_fraction = float(np.mean(glint_mask))
    passed = glint_fraction > 0.001
    confidence = min(1.0, glint_fraction * 200)
    return CheckOut(passed=passed, confidence=round(confidence, 3), detail=f"glint_fraction={glint_fraction:.5f}")


def hologram_check_dual(frame1_data_url: str, frame2_data_url: str) -> CheckOut:
    """
    [9/15] Real dual-frame hologram check. A genuine hologram/OVI (optically
    variable ink) patch shifts brightness/color/position of its glints as
    the viewing angle changes — a photo or screenshot of an ID does not,
    since it has no physical foil to catch the light differently. This
    compares the single-frame glint masks (bright + saturated small patches)
    from two angled frames of the same tilt phase: genuine foil shows glints
    that move/change between frames; a flat fake shows nearly the same glint
    pattern (or none) in both.
    """
    img1 = data_url_to_cv2(frame1_data_url)
    img2 = data_url_to_cv2(frame2_data_url)

    def glint_mask(img):
        h, w = img.shape[:2]
        img = cv2.resize(img, (400, int(400 * h / w))) if w else img
        hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
        sat = hsv[:, :, 1]
        val = hsv[:, :, 2]
        return ((val > 200) & (sat > 50)).astype(np.uint8)

    m1 = glint_mask(img1)
    m2 = glint_mask(img2)
    # Align sizes defensively (frames may differ slightly in aspect ratio).
    h = min(m1.shape[0], m2.shape[0])
    w = min(m1.shape[1], m2.shape[1])
    m1, m2 = m1[:h, :w], m2[:h, :w]

    glint_fraction_1 = float(np.mean(m1))
    glint_fraction_2 = float(np.mean(m2))
    has_some_glint = (glint_fraction_1 > 0.0008) or (glint_fraction_2 > 0.0008)

    # Position shift: IoU of the two glint masks. Real foil glints move
    # substantially with viewing angle (low IoU); a static fake image
    # tilted in front of the camera keeps roughly the same printed
    # highlights in place (high IoU).
    intersection = float(np.logical_and(m1, m2).sum())
    union = float(np.logical_or(m1, m2).sum())
    iou = intersection / union if union > 0 else 1.0
    moved = iou < 0.5

    passed = has_some_glint and moved
    # Confidence blends "there was something to see" with "it actually moved".
    confidence = min(1.0, (glint_fraction_1 + glint_fraction_2) * 100) * (1 - iou) if has_some_glint else 0.1
    confidence = round(min(1.0, max(0.0, confidence)), 3)
    return CheckOut(
        passed=passed,
        confidence=confidence,
        detail=f"glint_iou={iou:.3f} glint_frac_1={glint_fraction_1:.5f} glint_frac_2={glint_fraction_2:.5f}",
    )


_FACE_CASCADE = None


def _load_face_cascade():
    global _FACE_CASCADE
    if _FACE_CASCADE is not None:
        return _FACE_CASCADE
    path = cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
    _FACE_CASCADE = cv2.CascadeClassifier(path)
    return _FACE_CASCADE


def id_combo_check(data_url: str) -> "IdComboOut":
    """
    [5/15,14/15] Face + ID combo anti-spoof sanity check — NOT a full
    forensic check, a narrow "is this plausibly a real card held by a real
    live person, not a video/photo/screen replay" gate:
      1. face detected in frame (lightweight Haar cascade — cheap, no model
         download needed; swap for the InsightFace detector in face.py if
         you want higher accuracy and already pay that model-load cost
         elsewhere in the flow)
      2. a card-shaped region detected (a sufficiently large, roughly
         rectangular, high-contrast-edged contour, distinct from the face)
      3. the two are at a sane relative distance/size from each other (card
         not so far away it's illegible, not covering/overlapping the face)
      4. the frame itself isn't a re-photographed screen (reuses the moiré
         frequency-domain screen_check heuristic)
    """
    from schemas import IdComboOut

    img = data_url_to_cv2(data_url)
    h, w = img.shape[:2]
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    # 1. Face detection.
    face_cascade = _load_face_cascade()
    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(60, 60))
    face_detected = len(faces) > 0
    face_box = max(faces, key=lambda f: f[2] * f[3]) if face_detected else None

    # 2. Card-shaped region: look for a large rectangular contour with an ID
    # card-like aspect ratio (~1.4:1 to ~1.8:1), excluding the face area.
    edges = cv2.Canny(gray, 40, 120)
    edges = cv2.dilate(edges, np.ones((3, 3), np.uint8), iterations=1)
    contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    card_box = None
    best_score = 0.0
    frame_area = h * w
    for c in contours:
        area = cv2.contourArea(c)
        if area < frame_area * 0.03:  # too small to be a held-up card
            continue
        x, y, cw, ch = cv2.boundingRect(c)
        if cw == 0 or ch == 0:
            continue
        aspect = max(cw, ch) / max(1, min(cw, ch))
        if not (1.2 <= aspect <= 2.2):
            continue
        # Skip regions that mostly overlap the detected face — that's a
        # head, not a card.
        if face_box is not None:
            fx, fy, fw, fh = face_box
            ix = max(0, min(x + cw, fx + fw) - max(x, fx))
            iy = max(0, min(y + ch, fy + fh) - max(y, fy))
            overlap = ix * iy
            if overlap > 0.5 * (cw * ch):
                continue
        score = area / frame_area
        if score > best_score:
            best_score = score
            card_box = (x, y, cw, ch)
    card_detected = card_box is not None

    # 3. Relative distance/size sanity check.
    distance_ok = False
    if face_detected and card_detected:
        fx, fy, fw, fh = face_box
        cx, cy, cw, ch = card_box
        face_area = fw * fh
        card_area = cw * ch
        ratio = card_area / max(1, face_area)
        # Card shouldn't be tiny (too far away / unreadable) or huge
        # (covering the face / held right at the lens).
        distance_ok = 0.15 <= ratio <= 4.0

    # 4. Not a re-photographed screen (reuse the moiré heuristic).
    screen_res = screen_check(data_url)
    not_screen = screen_res.passed

    passed = face_detected and card_detected and distance_ok and not_screen
    signals_passed = sum([face_detected, card_detected, distance_ok, not_screen])
    confidence = round(signals_passed / 4, 3)

    return IdComboOut(
        passed=passed,
        confidence=confidence,
        faceDetected=face_detected,
        cardDetected=card_detected,
        distanceOk=distance_ok,
        notScreen=not_screen,
        detail=f"face={face_detected} card={card_detected} distance_ok={distance_ok} not_screen={not_screen}",
    )


def font_check(data_url: str) -> CheckOut:
    """
    Proxy for font-consistency: measures stroke-width variance across
    detected text-like contours. Genuine printed ID fonts have very
    consistent stroke widths; hand-edited/replaced text (different font,
    different rendering engine) tends to show higher variance.
    """
    img = data_url_to_cv2(data_url)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    _, binary = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
    contours, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    stroke_widths = []
    for c in contours:
        area = cv2.contourArea(c)
        x, y, w, h = cv2.boundingRect(c)
        if area < 8 or w == 0 or h == 0:
            continue
        # only look at text-like glyph boxes
        if 3 < h < 40 and 2 < w < 40:
            stroke_widths.append(area / max(h, 1))

    if len(stroke_widths) < 10:
        return CheckOut(passed=False, confidence=0.2, detail="not enough text detected")

    stroke_widths = np.array(stroke_widths)
    cv = float(np.std(stroke_widths) / (np.mean(stroke_widths) + 1e-6))  # coefficient of variation
    passed = cv < 0.6
    confidence = max(0.0, min(1.0, 1 - cv))
    return CheckOut(passed=passed, confidence=round(confidence, 3), detail=f"stroke_width_cv={cv:.3f}")


def template_match(data_url: str, doc_type: str | None = None) -> CheckOut:
    """
    ORB feature matching against a reference template layout for the given
    doc_type. Verifies the scanned card's layout (logo position, field
    positions) matches a known-good template rather than being a fully
    fabricated document. Requires you to drop reference images in
    templates/<doc_type>/reference.jpg — see README. Until you add
    templates, this returns passed=False with low confidence rather than a
    fake pass.
    """
    import os
    img = data_url_to_cv2(data_url)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    ref_path = os.path.join(TEMPLATES_DIR, doc_type or "default", "reference.jpg")
    if not os.path.exists(ref_path):
        return CheckOut(passed=False, confidence=0.0, detail=f"no reference template at {ref_path}")

    ref = cv2.imread(ref_path, cv2.IMREAD_GRAYSCALE)
    orb = cv2.ORB_create(nfeatures=800)
    kp1, des1 = orb.detectAndCompute(gray, None)
    kp2, des2 = orb.detectAndCompute(ref, None)
    if des1 is None or des2 is None:
        return CheckOut(passed=False, confidence=0.1, detail="feature extraction failed")

    bf = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True)
    matches = bf.match(des1, des2)
    good = [m for m in matches if m.distance < 50]
    match_ratio = len(good) / max(len(kp2), 1)

    passed = match_ratio > 0.15
    confidence = min(1.0, match_ratio * 3)
    return CheckOut(passed=passed, confidence=round(confidence, 3), detail=f"match_ratio={match_ratio:.3f}")
