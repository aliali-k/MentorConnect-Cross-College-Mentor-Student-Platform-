"""
Real, working phash implementation (no model download needed). The face-
embedding half of duplicate detection is actually done in the Node backend
(db.ts / session.ts), which keeps a JSON index of face embeddings and does
cosine similarity there — this module only needs to hand back a perceptual
hash of the document image for the backend to compare against past hashes.
"""
import imagehash
from imgutils import data_url_to_pil


def phash_of(data_url: str) -> str:
    img = data_url_to_pil(data_url)
    return str(imagehash.phash(img))


def hamming_distance(hash_a: str, hash_b: str) -> int:
    return imagehash.hex_to_hash(hash_a) - imagehash.hex_to_hash(hash_b)
