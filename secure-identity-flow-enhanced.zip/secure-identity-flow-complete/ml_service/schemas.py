from typing import Optional
from pydantic import BaseModel


class ImageIn(BaseModel):
    image: str  # data URL: "data:image/jpeg;base64,...."


class TemplateMatchIn(BaseModel):
    image: str
    doc_type: Optional[str] = None


class CheckOut(BaseModel):
    passed: bool
    confidence: float  # 0..1
    detail: Optional[str] = None


class DualFrameIn(BaseModel):
    frame1: str
    frame2: str


class IdComboOut(BaseModel):
    passed: bool
    confidence: float
    faceDetected: bool
    cardDetected: bool
    distanceOk: bool
    notScreen: bool
    detail: Optional[str] = None


class OcrOut(BaseModel):
    fields: dict[str, str]
    confidence: float
    rawText: str


class FaceMatchIn(BaseModel):
    id_photo: str
    selfie: str


class FaceMatchOut(BaseModel):
    match: bool
    similarity: float
    embedding: list[float]


class AntiSpoofIn(BaseModel):
    frames: list[str]


class AntiSpoofOut(BaseModel):
    live: bool
    score: float


class DuplicateCheckIn(BaseModel):
    embedding: list[float]
    phash: str


class DuplicateCheckOut(BaseModel):
    isDuplicate: bool
    matchedSessionId: Optional[str] = None
    similarity: float


class ExpiryCheckIn(BaseModel):
    fields: dict[str, str]


class ExpiryCheckOut(BaseModel):
    expired: bool
    expiryDate: Optional[str] = None
