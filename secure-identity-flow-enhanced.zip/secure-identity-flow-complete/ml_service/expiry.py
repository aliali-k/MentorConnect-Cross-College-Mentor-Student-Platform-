from datetime import datetime
from dateutil import parser as dateparser

EXPIRY_FIELD_CANDIDATES = ["expiry", "expiry_date", "date_of_expiry", "valid_until", "expires"]


def check_expiry(fields: dict[str, str]) -> tuple[bool, str | None]:
    raw = None
    for key in EXPIRY_FIELD_CANDIDATES:
        if key in fields and fields[key]:
            raw = fields[key]
            break
    if not raw:
        # no expiry field extracted by OCR — treat as unknown, not a hard fail
        return False, None
    try:
        dt = dateparser.parse(raw, dayfirst=True, fuzzy=True)
    except (ValueError, OverflowError):
        return False, None
    expired = dt.date() < datetime.utcnow().date()
    return expired, dt.date().isoformat()
